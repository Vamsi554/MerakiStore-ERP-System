
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `customer_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enquiry_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cash_amount` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `received_from_person` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_cheque` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_amount` int(11) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_from_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meraki_to_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_payment_amount` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_payments` WRITE;
/*!40000 ALTER TABLE `customer_payments` DISABLE KEYS */;
INSERT INTO `customer_payments` VALUES (1,'1','1',NULL,NULL,NULL,'HDFC Bank','98723248723',145000,'2018-11-12',NULL,NULL,NULL,NULL,NULL,NULL,145000,'2018-11-10 00:10:45','2018-11-10 00:10:45'),(2,'1','1',89300,'2018-11-20','Sudhakar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,89300,'2018-11-10 01:22:06','2018-11-10 01:22:06');
/*!40000 ALTER TABLE `customer_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `enquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `concernedLeadPerson` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enquiryCreDttm` date NOT NULL,
  `leadSource` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventPlace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizationName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eventDate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternatePhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enquiryStatus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enquiryComments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sampleDetailsSent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sampleDetailsComments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sampleReceivedByCustomer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `samplesCustomerFeedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `enquiries` WRITE;
/*!40000 ALTER TABLE `enquiries` DISABLE KEYS */;
INSERT INTO `enquiries` VALUES (1,'Vamsi Krishna','2018-11-09','Through Contacts','MERAKI_110918150551','Oracle UGBU Code Fest 2018','Hyderabad','Oracle India Private Limited','2018-11-30','Sudhakar Karumuri','9876907654','7789456789','Chief Event Organizer','sudhakar.karumuri@gmail.com','APPROVED','Enquiry has been Confirmed and Order has been created in the system.','Yes','Sample Hoodies & Bags have been shared with the Customer.','Yes','Customer liked the Quality of Hoodies & Bags and Requested for Pricing Details.','2018-11-09 09:35:51','2018-11-09 10:30:37');
/*!40000 ALTER TABLE `enquiries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `enquiry_quotation_linkages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiry_quotation_linkages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `quotation_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotation_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `enquiry_quotation_linkages` WRITE;
/*!40000 ALTER TABLE `enquiry_quotation_linkages` DISABLE KEYS */;
INSERT INTO `enquiry_quotation_linkages` VALUES (1,1,'MERAKI_QUOTE_110918153310','PENDING','2018-11-09 10:03:10','2018-11-09 10:03:10'),(2,1,'MERAKI_QUOTE_110918155115','APPROVED','2018-11-09 10:21:16','2018-11-09 10:30:37');
/*!40000 ALTER TABLE `enquiry_quotation_linkages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `enquiry_quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiry_quotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `quotation_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quoteCreDttm` date NOT NULL,
  `validity_date` date NOT NULL,
  `product_category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `hsn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fabric_colour` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_per_unit` int(11) NOT NULL,
  `gst_tax` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `additional_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `enquiry_quotations` WRITE;
/*!40000 ALTER TABLE `enquiry_quotations` DISABLE KEYS */;
INSERT INTO `enquiry_quotations` VALUES (1,1,'MERAKI_QUOTE_110918153310','2018-11-09','2018-11-09','Zipper Hoodie','Zipper Hoodie Export Quality',120,'6109','Black',1560,12,1572,NULL,'2018-11-09 10:03:10','2018-11-09 10:03:10'),(2,1,'MERAKI_QUOTE_110918153310','2018-11-09','2018-11-09','Laptop Bags','Laptop Bags',120,'2305','Black',450,10,460,NULL,'2018-11-09 10:03:10','2018-11-09 10:03:10'),(3,1,'MERAKI_QUOTE_110918155115','2018-11-09','2018-11-09','Zipper Hoodie','Zipper Hoodie Export Quality',120,'6109','Black',1375,12,1387,NULL,'2018-11-09 10:21:16','2018-11-09 10:21:16'),(4,1,'MERAKI_QUOTE_110918155115','2018-11-09','2018-11-09','Laptop Bags','Laptop Bags',120,'2305','Black',375,10,385,NULL,'2018-11-09 10:21:16','2018-11-09 10:21:16');
/*!40000 ALTER TABLE `enquiry_quotations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `enquiry_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiry_requirements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `product_category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `colour` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customizationDetails` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `front_panel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `back_panel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finishing` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fitting_sizes` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `packaging` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inclusive` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusive` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `est_delivery` date DEFAULT NULL,
  `breakup_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tech_pack_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `enquiry_requirements` WRITE;
/*!40000 ALTER TABLE `enquiry_requirements` DISABLE KEYS */;
INSERT INTO `enquiry_requirements` VALUES (7,1,'Zipper Hoodie',120,'Black','MODEL: Zipper Hoodie Pull Over with Pockets and Contrast hood # Material: Woollen # Quality: 350GSM # Fabric: Bio Wash # Print: Direct Printing # Packaging: Individual Poly pack #','Zipper Hoodie Export Quality','Oracle Code Fest Logo Design','Oracle Code Fest 2k18','Crease free, wrinkle free','S, M, L, XL, XXL, XXXL. (Sizes as per Indian Measurements)* - Male/Female','Packed as per the convenience','Product cost, Art work embroidery charges, Individual polythene cover packing, GST-5% and Fright charges','Any customization apart from the Inclusive','Approved','2018-11-22','Small (S) : 30, Medium (M) : 40, Large (L) : 40, X-Large (XL) : 10','2018-11-09','2018-11-09 10:13:48','2018-11-09 12:14:44'),(8,1,'Laptop Bags',120,'Black','600d PolyCanvas # Zippered main compartment # Fits most 15\" laptops # Mesh water bottle pocket # Adjustable, padded shoulder straps with a top grab handle #','Laptop Bags','Oracle Code Fest Logo Design','Oracle Code Fest 2k18','Crease Free, Winkle Free','15 inch | Will fit 15″ and smaller','Packed as per the convenience','Product cost, Art work embroidery charges, Individual polythene cover packing, GST-5% and Fright charges','Any customization apart from the Inclusive','Approved','2018-11-24','Black With Water Bottle Pouch: 60, Black Without Water Bottle Pouch: 60','2018-11-09','2018-11-09 10:13:48','2018-11-09 12:14:44');
/*!40000 ALTER TABLE `enquiry_requirements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',2),(6,'2018_08_23_143017_create_order_cycles_table',6),(7,'2018_08_30_181219_create_product_details_table',7),(8,'2018_08_30_181242_create_enquiry_quotations_table',8),(9,'2018_09_02_055353_create_enquiry_quotation_linkages_table',9),(11,'2018_10_15_175148_create_vendor_purchase_orders_table',11),(13,'2018_10_20_073650_create_vendors_table',13),(19,'2018_10_27_155032_create_order_status_updates_table',19),(20,'2018_10_31_171018_create_order_delivery_challans_table',20),(21,'2018_08_18_043653_create_enquiries_table',21),(29,'2018_08_18_100228_create_enquiry_requirements_table',24),(31,'2018_10_15_175211_create_vendor_purchase_orders_linkages_table',26),(32,'2018_10_24_180120_create_customer_payments_table',27),(33,'2018_10_24_180128_create_vendor_payments_table',27),(34,'2018_08_17_181219_create_orders_table',28),(35,'2018_09_27_004159_create_product_catalogs_table',29),(36,'2018_11_19_144428_create_notifications_table',30);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('34d13300-097b-495d-addc-aa8f163192d2','App\\Notifications\\UserActions','App\\User',1,'{\"data\":\"Bulusu\",\"link\":\"\\/enquiry\\/displayEnquiry\\/1\"}','2018-11-19 10:59:39','2018-11-19 10:27:22','2018-11-19 10:59:39'),('98aa5037-da0d-4258-9539-9127d87f0160','App\\Notifications\\UserActions','App\\User',2,'{\"data\":\"Vamsi Krishna\",\"link\":\"\\/enquiry\\/displayEnquiry\\/1\"}','2018-11-19 10:33:41','2018-11-19 10:14:29','2018-11-19 10:33:41'),('acbf03c7-d84b-46fc-8433-707ba5a15159','App\\Notifications\\UserActions','App\\User',2,'{\"data\":\"Bulusu\",\"link\":\"\\/enquiry\\/displayEnquiry\\/1\"}','2018-11-19 10:33:41','2018-11-19 10:27:22','2018-11-19 10:33:41'),('dd94affa-33a7-443c-a7af-8c662d7f5c25','App\\Notifications\\UserTasks','App\\User',1,'{\"data\":\"Work on ERP Designs\"}','2018-11-19 10:59:39','2018-11-19 10:47:18','2018-11-19 10:59:39'),('ee9fadc9-b510-45fc-8dd4-2e0837371711','App\\Notifications\\UserActions','App\\User',1,'{\"data\":\"Vamsi Krishna\",\"link\":\"\\/enquiry\\/displayEnquiry\\/1\"}','2018-11-19 10:59:39','2018-11-19 10:14:29','2018-11-19 10:59:39');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_cycles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enquiry_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `concernedLeadPerson` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `indicativeIcon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `logDate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logTime` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkDescription` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hyperLink` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalInfo` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_cycles` WRITE;
/*!40000 ALTER TABLE `order_cycles` DISABLE KEYS */;
INSERT INTO `order_cycles` VALUES (1,'1','IN PROGRESS','Vamsi Krishna','fa fa-envelope bg-yellow','Mr. Vamsi Krishna created merchandise enquiry for Oracle India Private Limited','Oracle India Private Limited is organizing Oracle UGBU Code Fest 2018 on 2018-11-30 at Hyderabad. As part of that event, enquiry has been created in the system to track the requirement details. View the Enquiry form below for more details.','09-Nov-2018','08:35 PM','View Enquiry','/enquiry/displayEnquiry/1','Mr. Vamsi Krishna added the comments: Oracle India Private Limited / Oracle UGBU Code Fest 2018 Enquiry Form','2018-11-09 09:35:51','2018-11-09 09:35:51'),(2,'1','IN PROGRESS','Vamsi Krishna','fa fa-envelope bg-yellow','Enquiry Updated','Mr. Vamsi Krishna Updated The Enquiry Details Upon Discussions With Customer And Admin.','09-Nov-2018','08:49 PM',NULL,NULL,'Mr. Vamsi Krishna added the comments: Updated the Samples Details Sent to the Customer as Part of Enquiry.','2018-11-09 09:49:37','2018-11-09 09:49:37'),(3,'1','REQUEST FOR QUOTATION','Vamsi Krishna','fa fa-envelope bg-yellow','Quotation Requested','Mr. Vamsi Krishna has requested for quotation price for the merchandise products listed in the enquiry. Awaiting counter action from Admin to review the enquiry and provide the quotation details.','09-Nov-2018','08:52 PM',NULL,NULL,'Mr. Vamsi Krishna added the comments: Requesting Admin for Quotation Pricing Details towards the Enquiry','2018-11-09 09:52:35','2018-11-09 09:52:35'),(4,'1','QUOTATION GENERATED','Abhilash','fa fa-envelope bg-yellow','Quotation Generated','Mr. Abhilash reviewed the enquiry details and provided the quotation for the best price to crack the deal. View the Quotation below for more details.','09-Nov-2018','09:03 PM','View Quotation','/enquiry/quotation/1/MERAKI_QUOTE_110918153310','Mr. Abhilash added the comments: Admin / Quotation Generated Online & Verified','2018-11-09 10:03:10','2018-11-09 10:03:10'),(5,'1','REQUEST FOR REVISED QUOTATION','Vamsi Krishna','fa fa-envelope bg-yellow','Revised Quotation Requested','Mr. Vamsi Krishna has requested again for quotation price for the merchandise products as customer is not in agreement with the quotation. Awaiting counter action from Admin to provide the revised quotation details.','09-Nov-2018','09:13 PM',NULL,NULL,'Mr. Vamsi Krishna added the comments: Requesting Admin for Revised Quotation as Customer is not satisfied with the pricing.','2018-11-09 10:13:48','2018-11-09 10:13:48'),(6,'1','REQUEST FOR REVISED QUOTATION','Abhilash','fa fa-envelope bg-yellow','Revised Quotation Generated','Mr. Abhilash reviewed the enquiry details and provided the quotation upon agreement with the customer to crack the deal. View the Revised Quotation below for more details.','09-Nov-2018','09:21 PM','View Revised Quotation','/enquiry/quotation/1/MERAKI_QUOTE_110918155115','Mr. Abhilash added the comments: Admin / Revised Quotation Generated Online & Verified','2018-11-09 10:21:16','2018-11-09 10:21:16'),(7,'1','REQUEST FOR ORDER CONFIRMATION','Vamsi Krishna','fa fa-envelope bg-yellow','Order Created. Mr. Vamsi Krishna Requested Admin For Order Confirmation.','Customer has agreed upon the quotation details. Mr. Vamsi Krishna has created the order and requested Admin for reviewing the order details and confirmation.','09-Nov-2018','09:30 PM','View Order','/order/displayOrder/1','Mr. Vamsi Krishna added the comments: Approving the Enquiry. Order Has Been Created In The System. Awaiting Admin Confirmation.','2018-11-09 10:30:37','2018-11-09 10:30:37'),(8,'1','APPROVED','Vamsi Krishna','fa fa-envelope bg-yellow','Enquiry Approved','Mr. Vamsi Krishna Approved the Enquiry. Proceeding with Creation of Order.','09-Nov-2018','09:30 PM','View Final Quotation','/enquiry/quotation/1/MERAKI_QUOTE_110918155115','Mr. Vamsi Krishna added the comments: Proceeding with the Order on the Final Quotation Below.','2018-11-09 10:30:37','2018-11-09 10:30:37'),(9,'1','ORDER CONFIRMED','Abhilash','fa fa-envelope bg-yellow','Order Confirmed','Mr. Abhilash Reviewed the Order Details and Confirmed the Order','09-Nov-2018','10:57 PM','View Order','/order/displayOrder/1',NULL,'2018-11-09 11:57:17','2018-11-09 11:57:17'),(10,'1','PROFORMA INVOICE & TECH PACK GENERATED','Abhilash','fa fa-envelope bg-yellow','Tech Pack Generated','Mr. Abhilash Has Generated The Tech Pack For The Order','09-Nov-2018','11:17 PM','View Tech Pack','/order/techPack/display/1/1',NULL,'2018-11-09 12:17:05','2018-11-09 12:17:05'),(11,'1','PROFORMA INVOICE & TECH PACK GENERATED','Abhilash','fa fa-envelope bg-yellow','Proforma Invoice Generated','Mr. Abhilash Has Generated The Proforma Invoice For The Order','09-Nov-2018','11:17 PM','View Proforma Invoice','/order/proformaInvoice/display/1/1',NULL,'2018-11-09 12:17:05','2018-11-09 12:17:05'),(12,'1','REQUEST FOR ADVANCE PAYMENT','Abhilash','fa fa-envelope bg-yellow','Advance Payment Requested','Mr. Abhilash Has Raised a Request To The Customer For Making An Advance Payment Towards The Order.','09-Nov-2018','11:19 PM',NULL,NULL,NULL,'2018-11-09 12:19:53','2018-11-09 12:19:53'),(13,'1','ADVANCE PAYMENT CONFIRMED','Abhilash','fa fa-envelope bg-yellow','Advance Payment Confirmed','Mr. Abhilash Has Confirmed That Advance Payment Has Been Received From the Customer.','10-Nov-2018','11:13 AM',NULL,NULL,'Mr. Abhilash added the comments: Advance Payment Has Been Received From The Customer. Payment Details Will be Added Shortly.','2018-11-10 00:13:08','2018-11-10 00:13:08'),(14,'1','ADVANCE PAYMENT RECEIPT GENERATED','Abhilash','fa fa-envelope bg-yellow','Advance Payment Receipt Generated','Mr. Abhilash Has Generated The Advance Payment Receipt For The Order','10-Nov-2018','11:13 AM','View Advance Payment Receipt','/order/paymentReceipt/display/1',NULL,'2018-11-10 00:13:43','2018-11-10 00:13:43'),(15,'1','PURCHASE ORDER CREATED','Abhilash','fa fa-envelope bg-yellow','Purchase Order Created','Mr. Abhilash Has Raised The Purchase Order With The Vendor','10-Nov-2018','11:33 AM','View Purchase Order','/order/admin/purchaseOrder/display/1/1',NULL,'2018-11-10 00:33:05','2018-11-10 00:33:05'),(16,'1','ORDER SENT TO PRODUCTION','Abhilash','fa fa-envelope bg-yellow','Order Sent To Production','Mr. Abhilash Has Confirmed The Order With The Production.','10-Nov-2018','11:36 AM',NULL,NULL,NULL,'2018-11-10 00:36:39','2018-11-10 00:36:39'),(17,'1','PRODUCTION SAMPLES REQUESTED','Abhilash','fa fa-envelope bg-yellow','Production Samples Requested','Mr. Abhilash Has Raised a Request To The Production Team For Providing Samples Towards The Order.','10-Nov-2018','11:43 AM',NULL,NULL,NULL,'2018-11-10 00:43:54','2018-11-10 00:43:54'),(18,'1','REVISED PRODUCTION SAMPLES REQUESTED','Abhilash','fa fa-envelope bg-yellow','Revised Production Samples Requested','Mr. Abhilash Has Raised a Request To The Production Team For Providing The Revised Samples Towards The Order.','10-Nov-2018','11:54 AM',NULL,NULL,NULL,'2018-11-10 00:54:52','2018-11-10 00:54:52'),(19,'1','PRODUCTION BULK PRINTING CONFIRMED','Abhilash','fa fa-envelope bg-yellow','Production Bulk Printing Confirmed','Mr. Abhilash Has Confirmed To Proceed With Mass Production.','10-Nov-2018','12:01 PM',NULL,NULL,'Mr. Abhilash added the comments: Customer Agreed With The Samples Products Provided. Confirming The Production Team To Proceed With Bulk Printing And Informing About The Tentative Delivery Dates.','2018-11-10 01:01:19','2018-11-10 01:01:19'),(20,'1','ORDER SHIPPED','Abhilash','fa fa-envelope bg-yellow','Order Shipped','Mr. Abhilash Has Confirmed Shipment Of The Order','10-Nov-2018','12:03 PM',NULL,NULL,NULL,'2018-11-10 01:03:03','2018-11-10 01:03:03'),(21,'1','DELIVERY CHALLAN GENERATED','Abhilash','fa fa-envelope bg-yellow','Delivery Challan Generated','Mr. Abhilash Has Generated The Delivery Challan For The Order','10-Nov-2018','12:09 PM',NULL,NULL,NULL,'2018-11-10 01:09:54','2018-11-10 01:09:54'),(22,'1','ORDER DELIVERED','Abhilash','fa fa-envelope bg-yellow','Order Delivered','Mr. Abhilash Has Confirmed With The Customer and Order Has Been Delivered.','10-Nov-2018','12:11 PM',NULL,NULL,NULL,'2018-11-10 01:11:20','2018-11-10 01:11:20'),(23,'1','TAX INVOICE GENERATED','Abhilash','fa fa-envelope bg-yellow','Tax Invoice Generated','Mr. Abhilash Has Generated The Tax Invoice For The Order','10-Nov-2018','12:15 PM','View Tax Invoice','/order/invoice/display/1',NULL,'2018-11-10 01:15:44','2018-11-10 01:15:44'),(24,'1','REQUEST FOR PENDING PAYMENT','Abhilash','fa fa-envelope bg-yellow','Requested For Pending Payment','Mr. Abhilash Has Requested With The Customer To Clear The Pending Payment Due.','10-Nov-2018','12:17 PM',NULL,NULL,NULL,'2018-11-10 01:17:21','2018-11-10 01:17:21'),(25,'1','FULL ORDER PAYMENT RECEIVED','Abhilash','fa fa-envelope bg-yellow','Full Payment Received','Mr. Abhilash Has Confirmed That Full Payment Has Been Received From the Customer.','10-Nov-2018','12:21 PM',NULL,NULL,'Mr. Abhilash added the comments: Full Payment Has Been Received From The Customer. Payment Receipt Details Will be Added Shortly.','2018-11-10 01:21:29','2018-11-10 01:21:29'),(26,'1','FINAL PAYMENT RECEIPT GENERATED','Abhilash','fa fa-envelope bg-yellow','Final Payment Receipt Generated','Mr. Abhilash Has Generated The Final Payment Receipt For The Order','10-Nov-2018','12:23 PM','View Final Payment Receipt','/order/paymentReceipt/display/1',NULL,'2018-11-10 01:23:23','2018-11-10 01:23:23'),(27,'1','ORDER COMPLETED','Abhilash','fa fa-envelope bg-yellow','Order Completed','Mr. Abhilash Has Completed The Order.','10-Nov-2018','12:30 PM','View Order Details','/order/displayOrder/1',NULL,'2018-11-10 01:30:33','2018-11-10 01:30:33');
/*!40000 ALTER TABLE `order_cycles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_delivery_challans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_delivery_challans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_challan_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_bill_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hsn_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_quantity` int(11) NOT NULL,
  `delivered_quantity` int(11) NOT NULL,
  `balance_quantity` int(11) NOT NULL,
  `transport_mode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_of_supply` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_delivery_challans` WRITE;
/*!40000 ALTER TABLE `order_delivery_challans` DISABLE KEYS */;
INSERT INTO `order_delivery_challans` VALUES (1,'1','MERAKI_DC_11101863554','1212121212','Zipper Hoodie Export Quality','6109',120,80,40,'Car','AP TV 1234','Hyderabad','2018-11-10 01:05:54','2018-11-10 01:05:54'),(2,'1','MERAKI_DC_11101863554','1212121212','Laptop Bags','2305',120,75,45,'Car','AP TV 1234','Hyderabad','2018-11-10 01:05:55','2018-11-10 01:05:55'),(3,'1','MERAKI_DC_11101863840','454545454545','Zipper Hoodie Export Quality','6109',120,40,0,'Car','AP ZX 9876','Hyderabad','2018-11-10 01:08:40','2018-11-10 01:08:40'),(4,'1','MERAKI_DC_11101863840','454545454545','Laptop Bags','2305',120,45,0,'Car','AP ZX 9876','Hyderabad','2018-11-10 01:08:40','2018-11-10 01:08:40');
/*!40000 ALTER TABLE `order_delivery_challans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_status_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_status_updates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enquiry_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_dttm` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_status_updates` WRITE;
/*!40000 ALTER TABLE `order_status_updates` DISABLE KEYS */;
INSERT INTO `order_status_updates` VALUES (1,'1','1','MERAKI_110918150551','REQUEST FOR ORDER CONFIRMATION','Requesting Admin to Confirm the Order','Vamsi Krishna','09-Nov-2018 09:48 PM','2018-11-09 10:48:49','2018-11-09 10:48:49'),(2,'1','1','MERAKI_110918150551','ORDER CONFIRMED','Proforma Invoice and Tech Pack have been generated. Proceeding with next stages of processing the order.','Abhilash','09-Nov-2018 11:16 PM','2018-11-09 12:16:57','2018-11-09 12:16:57'),(3,'1','1','MERAKI_110918150551','REQUEST FOR ADVANCE PAYMENT','Requesting Customer to make an advance payment to proceed with the order. Sales team to follow up with the customer.','Abhilash','09-Nov-2018 11:20 PM','2018-11-09 12:20:31','2018-11-09 12:20:31'),(4,'1','1','MERAKI_110918150551','ADVANCE PAYMENT RECEIPT GENERATED','Payment Receipt generated online and verified. Please share it with the customer.','Abhilash','10-Nov-2018 11:16 AM','2018-11-10 00:16:50','2018-11-10 00:16:50'),(5,'1','1','MERAKI_110918150551','PURCHASE ORDER CREATED','Purchase Order has been created and shared with the vendor. Awaiting his confirmation','Abhilash','10-Nov-2018 11:35 AM','2018-11-10 00:35:54','2018-11-10 00:35:54'),(6,'1','1','MERAKI_110918150551','PURCHASE ORDER CREATED','Vendor Mr. Suresh confirmed the order. Proceeding the order with the production,','Abhilash','10-Nov-2018 11:36 AM','2018-11-10 00:36:27','2018-11-10 00:36:27'),(7,'1','1','MERAKI_110918150551','ORDER SENT TO PRODUCTION','Order has been confirmed to the production. Vendor Initial Payment has been made. Adding the details shortly.','Abhilash','10-Nov-2018 11:39 AM','2018-11-10 00:39:59','2018-11-10 00:39:59'),(8,'1','1','MERAKI_110918150551','ORDER SENT TO PRODUCTION','Initial payment of Rs.100000/- has been made to the vendor. Pending amount will be cleared upon order dispatch.','Abhilash','10-Nov-2018 11:43 AM','2018-11-10 00:43:18','2018-11-10 00:43:18'),(9,'1','1','MERAKI_110918150551','PRODUCTION SAMPLES REQUESTED','Requesting Production team for samples before proceeding with bulk order.','Abhilash','10-Nov-2018 11:44 AM','2018-11-10 00:44:35','2018-11-10 00:44:35'),(10,'1','1','MERAKI_110918150551','PRODUCTION SAMPLES RECEIVED. AWAITING CUSTOMER CONFIRMATION','Production samples received from the production team. Will present it to customer for confirmation','Vamsi Krishna','10-Nov-2018 11:48 AM','2018-11-10 00:48:54','2018-11-10 00:48:54'),(11,'1','1','MERAKI_110918150551','INCORPORATING CUSTOMER FEEDBACK. REQUEST FOR REVISED SAMPLES','Logo Size to be increased a little on the Hoodie.','Vamsi Krishna','10-Nov-2018 11:51 AM','2018-11-10 00:51:52','2018-11-10 00:51:52'),(12,'1','1','MERAKI_110918150551','REVISED PRODUCTION SAMPLES CONFIRMED','Customer confirmed the revised production samples. Proceed with bulk printing on these changes.','Abhilash','10-Nov-2018 12:01 PM','2018-11-10 01:01:12','2018-11-10 01:01:12'),(13,'1','1','MERAKI_110918150551','ORDER SHIPPED','Delivery Challans are generated and order is delivered to the customer.,','Abhilash','10-Nov-2018 12:09 PM','2018-11-10 01:09:47','2018-11-10 01:09:47');
/*!40000 ALTER TABLE `order_status_updates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `concernedLead` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderCreDttm` date NOT NULL,
  `expectedDelivery` date NOT NULL,
  `orderStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderAmount` int(11) NOT NULL,
  `vendorAmount` int(11) DEFAULT NULL,
  `orderDetails` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderSummary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `billingAddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipmentAddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPersonAtShipment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactNumberAtShipment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postOrderDeliveryComments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clientFeedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotationNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '///////////////',
  `purchaseOrderNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '///////////////',
  `proformaInvoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '///////////////',
  `techPackNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '///////////////',
  `advancePaymentPercentage` int(11) NOT NULL DEFAULT '0',
  `invoiceDate` date DEFAULT NULL,
  `invoiceDueDate` date DEFAULT NULL,
  `GSTIN` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '36BOPPG4920P1ZD',
  `client_gst_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '///////////////',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,'Vamsi Krishna','sudhakar.karumuri@gmail.com','MERAKI_110918150551','2018-11-09','2018-11-26','ORDER COMPLETED',234300,163200,'Event Details : Oracle UGBU Code Fest 2018, Hyderabad / Organization : Oracle India Private Limited','120 Units Of Zipper Hoodie Export Quality / 120 Units Of Laptop Bags','Oracle India Private Limited, Tower C Ananth Info Park, Hitech City, Hyderabad - 500081','Oracle India Private Limited, Tower C Ananth Info Park, Hitech City, Hyderabad - 500081','Sudhakar','7789093456',NULL,NULL,'MERAKI_QUOTE_110918155115','MERAKI_PO_11101855159','MERAKI_PROFORMA_110918173605','MERAKI_TECHPACK_110918174444',40,'2018-11-15','2018-11-27','36BOPPG4920P1ZD','34FRTVRGSTIN233','2018-11-09 10:30:37','2018-11-10 01:30:33');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_catalogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_catalogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_category_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `art_work` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hsn_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gst_tax` decimal(10,2) NOT NULL,
  `product_style` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `material` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `print_methods` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `print_placements` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `print_area` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `measurements` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `customizations` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `finishing` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `packaging` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `inclusive` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusive` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_information` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_catalogs_product_category_code_unique` (`product_category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_catalogs` WRITE;
/*!40000 ALTER TABLE `product_catalogs` DISABLE KEYS */;
INSERT INTO `product_catalogs` VALUES (1,'T-Shirt','MERAKI_TSHIRT_001','Customized T-Shirt','Embroidery','6019',5.00,'Enable@Half Sleeve#Enable@Full Sleeve#Enable@Round Neck#Enable@V-Neck#Enable@Chinese Collar','Enable@Cotton#Enable@Polyster#Enable@Semi-Cotton','Enable@Red#Enable@Violet#Enable@Blue#Enable@Green#Enable@Yellow#Enable@Orange#Enable@Pink','Enable@Sublimation#Enable@Direct Printing#Enable@Water Based#Enable@PVC#Enable@Non-PVC','Enable@Pocket#Enable@Back Side#Enable@Stomach#Enable@Sleeve','Enable@A5#Enable@A4#Enable@A3#Enable@Pocket Side','Enable@Small#Enable@Medium#Enable@Large#Enable@Extra Large#Enable@Double Extra Large#Enable@Triple Extra Large','Enable@Front Panel Customization#Enable@Back Panel Customization#Enable@Side Panel Customization','Enable@Crease Free, Wrinkle Free','Enable@Single Unit Packaging#Enable@Bulk Packaging','Enable@Product Cost#Enable@Art Work#Enable@Printing#Enable@Embroidery#Enable@Customized Sizes#Enable@Shipment#Enable@Packing#Enable@GST','Enable@Any Customization apart from Inclusive','Abhilash','Meraki Customized T-Shirt Product Suite','2018-11-17 19:46:11','2018-11-17 19:46:11');
/*!40000 ALTER TABLE `product_catalogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_descr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `front_panel_design` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `back_panel_design` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finishing` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fitting_sizes` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `packaging` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inclusive` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusive` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_5` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_details` WRITE;
/*!40000 ALTER TABLE `product_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'No',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Vamsi Krishna','vamsikrish554@gmail.com','$2y$10$8J0faEFw0LCXAGNe/lRoAex4zrkuUtqUbaOHz5VcBKKlMQQK/q09G','No','ybDBIkxvOhpELYEKW3NbyFU10QR5KAGLcWjKgqpvstftmmS9eSyxzYZ7cjVc','2018-09-10 12:12:19','2018-09-10 12:12:19'),(2,'Abhilash','abhilash.merakii@gmail.com','$2y$10$sS0/jYSmrrezGYnfMfGuXumhUVVYvoX9dQvLLpuaZ9JbKY2vMr9P2','Yes','URGddsNBWNRIjaHrcSZa7m4PR3HgjMnECwtqGpIuu8x63AukTc4o40qblcW8','2018-11-03 05:20:10','2018-11-03 05:20:10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vendor_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enquiry_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cash_amount` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `paid_to_person` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_cheque` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_amount` int(11) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meraki_from_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_to_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_payment_amount` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vendor_payments` WRITE;
/*!40000 ALTER TABLE `vendor_payments` DISABLE KEYS */;
INSERT INTO `vendor_payments` VALUES (1,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TRN0987732323','ICICI Bank','5002032832476','2342434535641',100000,'2018-11-12',100000,'2018-11-10 00:40:44','2018-11-10 00:40:44'),(2,'1','1',63200,'2018-11-20','Mr. Suresh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,63200,'2018-11-10 01:28:45','2018-11-10 01:28:45');
/*!40000 ALTER TABLE `vendor_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vendor_purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_purchase_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `purchase_order_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poCreDttm` date NOT NULL,
  `validity_date` date NOT NULL,
  `product_category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_features` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `fabric_colour` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_per_unit` int(11) NOT NULL,
  `gst_tax` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `additional_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vendor_purchase_orders` WRITE;
/*!40000 ALTER TABLE `vendor_purchase_orders` DISABLE KEYS */;
INSERT INTO `vendor_purchase_orders` VALUES (3,1,'MERAKI_PO_11101855159','2018-11-10','2018-11-10','Zipper Hoodie','Zipper Hoodie Export Quality','MODEL: Zipper Hoodie Pull Over with Pockets and Contrast hood # Material: Woollen # Quality: 350GSM # Fabric: Bio Wash # Print: Direct Printing # Packaging: Individual Poly pack #',120,'Black',975,60,1035,NULL,'2018-11-10 00:31:09','2018-11-10 00:31:09'),(4,1,'MERAKI_PO_11101855159','2018-11-10','2018-11-10','Laptop Bags','Laptop Bags','600d PolyCanvas # Zippered main compartment # Fits most 15\" laptops # Mesh water bottle pocket # Adjustable, padded shoulder straps with a top grab handle #',120,'Black',275,50,325,NULL,'2018-11-10 00:31:09','2018-11-10 00:31:09');
/*!40000 ALTER TABLE `vendor_purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vendor_purchase_orders_linkages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_purchase_orders_linkages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `purchase_order_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_terms_conditions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_payment_amount` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vendor_purchase_orders_linkages` WRITE;
/*!40000 ALTER TABLE `vendor_purchase_orders_linkages` DISABLE KEYS */;
INSERT INTO `vendor_purchase_orders_linkages` VALUES (1,1,'MERAKI_PO_11101855159','MERAKI_SURESH','Enable@Terms & Conditions 1#Enable@Terms & Conditions 2#Enable@Terms & Conditions 3#Enable@Terms & Conditions 4#Enable@Terms & Conditions 5','Special Notes 1 & Special Notes 2',163200,'2018-11-10 00:22:00','2018-11-10 00:31:09');
/*!40000 ALTER TABLE `vendor_purchase_orders_linkages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_company` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_address1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_address2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_TIN` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_CST` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` VALUES (1,'MERAKI_SURESH','Suresh','09443973080','S.P. CERATION','Plot No.22','Chellam Nagar','Street No: 2','Iduvampalayam(PO), Tirupur','Tamil Nadu','641604','33946363696','1178872','2018-10-20 02:58:30','2018-10-20 04:09:30'),(2,'MERAKI_VAMSI','Vamsi Krishna','8790235431','V. K. Print Creations','Plot No: 101','Balaji Nagar','Bachupally Road, Miyapur','Hyderabad','Telangana','500049','1212121212','878787','2018-10-20 04:27:01','2018-10-20 04:27:01');
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

