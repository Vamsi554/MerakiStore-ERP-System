<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Vendor | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

            <div class="box-header">
              <h3 class="box-title"> <?php echo e($vendor->vendor_code); ?> </h3>
            </div>

            <div class="box-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> Vendor Details </h4>

                       <tr>
                           <td style="width:30%">Vendor Code</td>
                           <td>
                             <?php echo e($vendor->vendor_code); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor Name</td>
                           <td>
                             <?php echo e($vendor->vendor_name); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor Phone</td>
                           <td>
                             <?php echo e($vendor->vendor_phone); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor Company</td>
                           <td>
                             <?php echo e($vendor->vendor_company); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor Address 1</td>
                           <td>
                             <?php echo e($vendor->vendor_address1); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor Address 2</td>
                           <td>
                             <?php echo e($vendor->vendor_address2); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Street</td>
                           <td>
                             <?php echo e($vendor->street); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">City</td>
                           <td>
                             <?php echo e($vendor->city); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">State</td>
                           <td>
                             <?php echo e($vendor->state); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Zip Code</td>
                           <td>
                             <?php echo e($vendor->zipcode); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor TIN</td>
                           <td>
                             <?php echo e($vendor->vendor_TIN); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Vendor CST</td>
                           <td>
                             <?php echo e($vendor->vendor_CST); ?>

                           </td>
                       </tr>

                  </table>

               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>