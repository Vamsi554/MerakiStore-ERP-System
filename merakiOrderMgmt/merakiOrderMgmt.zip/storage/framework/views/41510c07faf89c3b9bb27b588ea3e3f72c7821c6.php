<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Tasks
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tasks | Meraki Store</h3>
            </div>

            <div class="box-body">

              <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>

               <form method="POST" action="/task/updateTask/<?php echo e($task->id); ?>" autocomplete="off">
                 <table id="example1" class="table table-bordered table-striped">

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">


                       <tr class="<?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                           <td>Task Title</td>
                           <td>
                               <input type="text" id="title" name="title" size="27"
                               style="width:100%!important" value="<?php echo e($task->title); ?>">
                               <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                           </td>
                       </tr>

                       <tr class="<?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
                           <td>Task Body</td>
                           <td>
                               <textarea rows="6" cols="27" id="body" name="body"
                                style="width:100%!important">
                                <?php echo e($task->body); ?>

                               </textarea>
                               <span class="text-danger"><?php echo e($errors->first('body')); ?></span>
                           </td>
                       </tr>
              </table>
              <button class="btn btn-primary" type="submit">Update Task</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>