<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        User | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

            <div class="box-header">
              <h3 class="box-title"> <?php echo e($user->name); ?> </h3>
            </div>

            <div class="box-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> User Details </h4>

                       <tr>
                           <td style="width:30%">Email</td>
                           <td>
                             <?php echo e($user->email); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">First Name</td>
                           <td>
                             <?php echo e($user->first_name); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Last Name</td>
                           <td>
                             <?php echo e($user->last_name); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Role</td>
                           <td>
                             <?php echo e($user->role); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Department</td>
                           <td>
                             <?php echo e($user->department); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Contact</td>
                           <td>
                             <?php echo e($user->contact); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Address</td>
                           <td>
                             <?php echo e($user->address); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Joining Date</td>
                           <td>
                             <?php echo e(date('d-M-Y', strtotime($user->hire_date))); ?>

                           </td>
                       </tr>

                  </table>

               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>