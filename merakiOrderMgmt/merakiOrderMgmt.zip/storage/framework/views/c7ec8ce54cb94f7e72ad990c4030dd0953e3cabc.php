<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Order Lifecycle
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <ul class="timeline">
          <?php $__currentLoopData = $orderCycle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li class="time-label">
                <span class="bg-red">
                  <?php echo e($cycle->logDate); ?>

                </span>
            </li>

            <li>
              <i class="<?php echo e($cycle->indicativeIcon); ?>"></i>
              <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i> <?php echo e($cycle->logTime); ?> </span>
                <h3 class="timeline-header"><?php echo e($cycle->subject); ?></h3>
                <div class="timeline-body">
                  <?php echo e($cycle->content); ?>

                  <br>
                </div>
                <?php
                  $orderStatusLines = $orderStatusUpdates->where('order_status', $cycle->order_status);
                ?>
                <?php if(count($orderStatusLines) > 0): ?>
                  <b class="timeline-body"> Status Updates </b>
                  <ul>
                  <?php $__currentLoopData = $orderStatusLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <b> On <?php echo e($statusLine->creation_dttm); ?>, Mr. <?php echo e($statusLine->user); ?> Added : </b> <?php echo e($statusLine->comments); ?></li> <br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                <?php endif; ?>
                <div class="timeline-body">
                  <?php if($cycle->additionalInfo != null): ?>
                    <b>Additional Information : </b> <?php echo e($cycle->additionalInfo); ?>

                  <?php endif; ?>
                </div>
                <?php if($cycle->hyperLink AND $cycle->linkDescription): ?>
                  <div class="timeline-footer">
                    <a href="<?php echo e(url($cycle->hyperLink)); ?>" target="_blank" class="btn btn-primary btn-xs"><?php echo e($cycle->linkDescription); ?></a>
                  </div>
                <?php endif; ?>
              </div>
            </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <li>
              <i class="fa fa-clock-o bg-gray"></i>
            </li>

    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>