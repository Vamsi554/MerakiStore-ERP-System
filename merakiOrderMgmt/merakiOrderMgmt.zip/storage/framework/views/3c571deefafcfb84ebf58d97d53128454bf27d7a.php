<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Product Catalog
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Products | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Product Code</th>
                  <th>Product Category</th>
                  <th>Description</th>
                  <th>Art Work</th>
                  <th>HSN/SAC</th>
                  <th>GST (%)</th>
                  <th>Created By</th>
                  <th>Update</th>
                  <th>View</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $productCatalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($product->product_category_code); ?></td>
                    <td><?php echo e($product->product_category); ?></td>
                    <td><?php echo e($product->product_description); ?></td>
                    <td><?php echo e($product->art_work); ?></td>
                    <td><?php echo e($product->hsn_code); ?></td>
                    <td><?php echo e($product->gst_tax); ?></td>
                    <td><?php echo e($product->created_by); ?></td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/productCatalog/updateProduct/<?php echo e($product->id); ?>" class="btn btn-warning ml-2">Update</a>
                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/productCatalog/displayProduct/<?php echo e($product->id); ?>" class="btn btn-info ml-2">View</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <a href="<?php echo e(URL::to('/')); ?>/productCatalog/createProduct" class="btn btn-primary ml-2">Add Product</a>

    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>