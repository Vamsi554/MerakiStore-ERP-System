<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php echo e($title); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Order | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>SNo</th>
                  <th>Organization</th>
                  <th>Order Status</th>
                  <th>Expected Delivery</th>
                  <th>Merchandise</th>
                  <th>Note</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Track</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $sNo = 1
                ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($sNo++); ?></td>
                    <td><?php echo e($order->orderDetails); ?></td>
                    <td><?php echo e($order->orderStatus); ?></td>
                    <?php
                      $createDate = $order->orderCreDttm;
                      $deliveryDate = $order->expectedDelivery;
                      $currentDate = \Carbon\Carbon::now("Asia/Kolkata");
                      $diff = abs(strtotime($deliveryDate) - strtotime($currentDate));
                      $years = floor($diff / (365*60*60*24));
                      $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                      $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                    ?>
                    <td style="width:10%;">
                      <?php echo e(date('d-M-Y', strtotime($order->expectedDelivery))); ?> <br><br>
                      <?php if($years > 0): ?>
                        <?php if($years > 1): ?>
                          <?php echo e($years); ?> Years and
                        <?php else: ?>
                          <?php echo e($years); ?> Year and
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if($months > 0): ?>
                        <?php if($months > 1): ?>
                          <?php echo e($months); ?> Months and
                        <?php else: ?>
                          <?php echo e($months); ?> Month and
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if($days > 0): ?>
                        <?php if($days > 1): ?>
                          <?php echo e($days); ?> Days Left.
                        <?php else: ?>
                          <?php echo e($days); ?> Day Left.
                        <?php endif; ?>
                      <?php endif; ?>
                    <td><?php echo e($order->orderSummary); ?> <br><br><b><i> Amount : Rs.<?php echo e($order->orderAmount); ?>/- </i></b></td>
                    <td>
                      <a href="#addStatusUpdateModal" class="btn btn-primary ml-2" data-toggle="modal">Note</a>

                      <div class="modal fade" id="addStatusUpdateModal" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/statusUpdate/save/<?php echo e($order->id); ?>" autocomplete="off">
                              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title"> Add Status Update To This Order </h4>
                              </div>
                              <div class="modal-body">
                                <b>Document Number : </b> <?php echo e($order->documentNumber); ?>

                                <br><br>
                                <b>Summary : </b> <?php echo e($order->orderDetails); ?>

                                <br><br>
                                <b>Merchandise : </b> <?php echo e($order->orderSummary); ?>

                                <br><br>
                                <b>Status : </b> <?php echo e($order->orderStatus); ?>

                                <br><br>
                                <b>Note : </b> <br><br>
                                <textarea rows="4" cols="50" class="form-control" type="text" id="orderStatusUpdate"
                                name="orderStatusUpdate" size="100" style="width:100%!important"
                                value="<?php echo e(old('sampleDetailsComments')); ?>" required></textarea>
                                <br>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>

                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/order/updateOrder/<?php echo e($order->id); ?>" class="btn btn-warning ml-2">Update</a>
                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/order/displayOrder/<?php echo e($order->id); ?>" class="btn btn-info ml-2">View</a>
                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/order/lifecycle/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" target="_blank">Lifecycle</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <h4 class="text-capitalize"> Start creating new order by filling out the enquiry form below </h4>
      <br/>

      <a href="<?php echo e(URL::to('/')); ?>/enquiry/createEnquiry" class="btn btn-primary ml-2">Create Enquiry</a>

    </section>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>