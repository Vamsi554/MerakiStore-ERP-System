<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Product Catalog | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Product Catalog Form </h3>
            </div>

            <div class="box-body">
               <form method="POST" class="form-group" action="<?php echo e(URL::to('/')); ?>/productCatalog/updateProduct/<?php echo e($productCatalog->id); ?>" autocomplete="off">

                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                 <input type="hidden" name="concernedLeadPerson" id="concernedLeadPerson" value="<?php echo e(Auth::user()->name); ?>">

                 <div class="row">
                   <div class="col-md-12">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Product Details </h4>

                           <tr class="<?php echo e($errors->has('productCategory') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Product Category</td>
                               <td>
                                 <input class="form-control" type="text" id="productCategory"
                                 name="productCategory" size="27" style="width:100%!important" value="<?php echo e($productCatalog->product_category); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('productCategory')); ?></span>
                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('productCategoryCode') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Product Category Code</td>
                               <td>
                                 <input class="form-control" type="text" id="productCategoryCode"
                                 name="productCategoryCode" size="27" style="width:100%!important" value="<?php echo e($productCatalog->product_category_code); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('productCategoryCode')); ?></span>
                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('productDescr') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Product Description</td>
                               <td>
                                 <input class="form-control" type="text" id="productDescr"
                                 name="productDescr" size="27" style="width:100%!important" value="<?php echo e($productCatalog->product_description); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('productDescr')); ?></span>
                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('artWork') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Art Work</td>
                               <td>
                                 <input class="form-control" type="text" id="artWork"
                                 name="artWork" size="27" style="width:100%!important" value="<?php echo e($productCatalog->art_work); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('artWork')); ?></span>
                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('hsnCode') ? 'has-error' : ''); ?>">
                               <td style="width:30%">HSN Code</td>
                               <td>
                                 <input class="form-control" type="text" id="hsnCode"
                                 name="hsnCode" size="27" style="width:100%!important" value="<?php echo e($productCatalog->hsn_code); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('hsnCode')); ?></span>
                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('gstPer') ? 'has-error' : ''); ?>">
                               <td style="width:30%">GST Tax (%)</td>
                               <td>
                                 <input class="form-control" type="number" step="any" id="gstPer"
                                 name="gstPer" size="27" style="width:100%!important" value="<?php echo e($productCatalog->gst_tax); ?>" required>
                                 <span class="text-danger"><?php echo e($errors->first('gstPer')); ?></span>
                               </td>
                           </tr>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <h2>Product Features</h2>
                          <?php
                              $prodStyleFeaturesArr = explode("#", $productCatalog->product_style);
                              $prodStyleStatusArr = array();
                              $prodStyleFeatureTextArr = array();

                              for($i=0; $i<count($prodStyleFeaturesArr); $i++) {

                                  $features = explode("@", $prodStyleFeaturesArr[$i]);
                                  $prodStyleStatusArr[$i] = $features[0];
                                  $prodStyleFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Product Style</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="prodStyle">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($prodStyleStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="prodStyleStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($prodStyleStatusArr[$v]); ?></option>
                                     <?php if($prodStyleStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($prodStyleStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="prodStyleFeatureText[]" value="<?php echo e($prodStyleFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $materialFeaturesArr = explode("#", $productCatalog->material);
                              $materialStatusArr = array();
                              $materialFeatureTextArr = array();

                              for($i=0; $i<count($materialFeaturesArr); $i++) {

                                  $features = explode("@", $materialFeaturesArr[$i]);
                                  $materialStatusArr[$i] = $features[0];
                                  $materialFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Material</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="material">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($materialStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="materialStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($materialStatusArr[$v]); ?></option>
                                     <?php if($materialStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($materialStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="materialFeatureText[]" value="<?php echo e($materialFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $qualityFeaturesArr = explode("#", $productCatalog->quality);
                              $qualityStatusArr = array();
                              $qualityFeatureTextArr = array();

                              for($i=0; $i<count($qualityFeaturesArr); $i++) {

                                  $features = explode("@", $qualityFeaturesArr[$i]);
                                  $qualityStatusArr[$i] = $features[0];
                                  $qualityFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Quality (GSM)</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="quality">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($qualityStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="qualityStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($qualityStatusArr[$v]); ?></option>
                                     <?php if($qualityStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($qualityStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="qualityFeatureText[]" value="<?php echo e($qualityFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $fabricFeaturesArr = explode("#", $productCatalog->fabric);
                              $fabricStatusArr = array();
                              $fabricFeatureTextArr = array();

                              for($i=0; $i<count($fabricFeaturesArr); $i++) {

                                  $features = explode("@", $fabricFeaturesArr[$i]);
                                  $fabricStatusArr[$i] = $features[0];
                                  $fabricFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Fabric</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="fabric">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($fabricStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="fabricStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($fabricStatusArr[$v]); ?></option>
                                     <?php if($fabricStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($fabricStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="fabricFeatureText[]" value="<?php echo e($fabricFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $addtProdFtFeaturesArr = explode("#", $productCatalog->additional_features);
                              $addtProdFtStatusArr = array();
                              $addtProdFtFeatureTextArr = array();

                              for($i=0; $i<count($addtProdFtFeaturesArr); $i++) {

                                  $features = explode("@", $addtProdFtFeaturesArr[$i]);
                                  $addtProdFtStatusArr[$i] = $features[0];
                                  $addtProdFtFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Additional Features</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="addtProdFt">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($addtProdFtStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="addtProdFtStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($addtProdFtStatusArr[$v]); ?></option>
                                     <?php if($addtProdFtStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($addtProdFtStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="addtProdFtFeatureText[]" value="<?php echo e($addtProdFtFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                        <h2>Product Customizations</h2>
                          <?php
                              $colorFeaturesArr = explode("#", $productCatalog->colour);
                              $colorStatusArr = array();
                              $colorFeatureTextArr = array();

                              for($i=0; $i<count($colorFeaturesArr); $i++) {

                                  $features = explode("@", $colorFeaturesArr[$i]);
                                  $colorStatusArr[$i] = $features[0];
                                  $colorFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Colour</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="colour">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($colorStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="colourStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($colorStatusArr[$v]); ?></option>
                                     <?php if($colorStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($colorStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="colourFeatureText[]" value="<?php echo e($colorFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $printMethFeaturesArr = explode("#", $productCatalog->print_methods);
                              $printMethStatusArr = array();
                              $printMethFeatureTextArr = array();

                              for($i=0; $i<count($printMethFeaturesArr); $i++) {

                                  $features = explode("@", $printMethFeaturesArr[$i]);
                                  $printMethStatusArr[$i] = $features[0];
                                  $printMethFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Print Methods</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="printMethod">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($printMethStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="printMethodStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($printMethStatusArr[$v]); ?></option>
                                     <?php if($printMethStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($printMethStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="printMethodFeatureText[]" value="<?php echo e($printMethFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $printPlcFeaturesArr = explode("#", $productCatalog->print_placements);
                              $printPlcStatusArr = array();
                              $printPlcFeatureTextArr = array();

                              for($i=0; $i<count($printPlcFeaturesArr); $i++) {

                                  $features = explode("@", $printPlcFeaturesArr[$i]);
                                  $printPlcStatusArr[$i] = $features[0];
                                  $printPlcFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Print Placements</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="printPlacement">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($printPlcStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="printPlacementStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($printPlcStatusArr[$v]); ?></option>
                                     <?php if($printPlcStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($printPlcStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="printPlacementFeatureText[]" value="<?php echo e($printPlcFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $printAreaFeaturesArr = explode("#", $productCatalog->print_area);
                              $printAreaStatusArr = array();
                              $printAreaFeatureTextArr = array();

                              for($i=0; $i<count($printAreaFeaturesArr); $i++) {

                                  $features = explode("@", $printAreaFeaturesArr[$i]);
                                  $printAreaStatusArr[$i] = $features[0];
                                  $printAreaFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Print Area</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="printArea">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($printAreaStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="printAreaStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($printAreaStatusArr[$v]); ?></option>
                                     <?php if($printAreaStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($printAreaStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="printAreaFeatureText[]" value="<?php echo e($printAreaFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $msmrtFeaturesArr = explode("#", $productCatalog->measurements);
                              $msmrtStatusArr = array();
                              $msmrtFeatureTextArr = array();

                              for($i=0; $i<count($msmrtFeaturesArr); $i++) {

                                  $features = explode("@", $msmrtFeaturesArr[$i]);
                                  $msmrtStatusArr[$i] = $features[0];
                                  $msmrtFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Measurements</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="measurements">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($msmrtStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="measurementsStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($msmrtStatusArr[$v]); ?></option>
                                     <?php if($msmrtStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($msmrtStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="measurementsFeatureText[]" value="<?php echo e($msmrtFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $addtCustFeaturesArr = explode("#", $productCatalog->additional_customizations);
                              $addtCustStatusArr = array();
                              $addtCustFeatureTextArr = array();

                              for($i=0; $i<count($addtCustFeaturesArr); $i++) {

                                  $features = explode("@", $addtCustFeaturesArr[$i]);
                                  $addtCustStatusArr[$i] = $features[0];
                                  $addtCustFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Additional Customizations</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="customizations">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($addtCustStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="customizationsStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($addtCustStatusArr[$v]); ?></option>
                                     <?php if($addtCustStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($addtCustStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="customizationsFeatureText[]" value="<?php echo e($addtCustFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                        <h2>Conditions</h2>
                          <?php
                              $finFeaturesArr = explode("#", $productCatalog->finishing);
                              $finStatusArr = array();
                              $finFeatureTextArr = array();

                              for($i=0; $i<count($finFeaturesArr); $i++) {

                                  $features = explode("@", $finFeaturesArr[$i]);
                                  $finStatusArr[$i] = $features[0];
                                  $finFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Finishing</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="finishing">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($finStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="finishingStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($finStatusArr[$v]); ?></option>
                                     <?php if($finStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($finStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="finishingFeatureText[]" value="<?php echo e($finFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $pkgFeaturesArr = explode("#", $productCatalog->packaging);
                              $pkgStatusArr = array();
                              $pkgFeatureTextArr = array();

                              for($i=0; $i<count($pkgFeaturesArr); $i++) {

                                  $features = explode("@", $pkgFeaturesArr[$i]);
                                  $pkgStatusArr[$i] = $features[0];
                                  $pkgFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Packaging</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="packaging">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($pkgStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="packagingStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($pkgStatusArr[$v]); ?></option>
                                     <?php if($pkgStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($pkgStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="packagingFeatureText[]" value="<?php echo e($pkgFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $incFeaturesArr = explode("#", $productCatalog->inclusive);
                              $incStatusArr = array();
                              $incFeatureTextArr = array();

                              for($i=0; $i<count($incFeaturesArr); $i++) {

                                  $features = explode("@", $incFeaturesArr[$i]);
                                  $incStatusArr[$i] = $features[0];
                                  $incFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Inclusive</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="inclusive">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($incStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="inclusiveStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($incStatusArr[$v]); ?></option>
                                     <?php if($incStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($incStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="inclusiveFeatureText[]" value="<?php echo e($incFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                          <?php
                              $excFeaturesArr = explode("#", $productCatalog->exclusive);
                              $excStatusArr = array();
                              $excFeatureTextArr = array();

                              for($i=0; $i<count($excFeaturesArr); $i++) {

                                  $features = explode("@", $excFeaturesArr[$i]);
                                  $excStatusArr[$i] = $features[0];
                                  $excFeatureTextArr[$i] = $features[1];
                              }
                          ?>
                          <h4 class="box-title">Exclusive</h4>
                          <table class="genericFeaturesTbl table table-bordered table-hover" id="exclusive">
                            <thead>
                              <tr>
                                <th class="text-center">Feature Confirmation</th>
                                <th class="text-center">Specification</th>
                                <th class="text-center">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php for($v=0; $v<count($excStatusArr); $v++): ?>
                                <tr>
                                  <td style="width:15%;">
                                    <select class="form-control" name="exclusiveStatus[]"
                                    value="<?php echo e(old('status')); ?>" required>
                                     <option selected="selected"><?php echo e($excStatusArr[$v]); ?></option>
                                     <?php if($excStatusArr[$v] != 'Enable'): ?>
                                       <option>Enable</option>
                                     <?php endif; ?>
                                     <?php if($excStatusArr[$v] != 'Disable'): ?>
                                       <option>Disable</option>
                                     <?php endif; ?>
                                    </select>
                                  </td>
                                  <td style="width:70%;">
                                    <input class="form-control" type="text" name="exclusiveFeatureText[]" value="<?php echo e($excFeatureTextArr[$v]); ?>" required>
                                  </td>
                                  <td>
                                    <p class="ibtnAdd btn btn-md btn-primary">Add</p>
                                    <p class="ibtnDel btn btn-md btn-danger" style="float:right;">Delete</p>
                                  </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                          </table>
                      </table>
                      <br>
                      <table class="table table-bordered table-striped">
                        <h4 class="box-title"> Additional Information </h4>
                        <tr class="<?php echo e($errors->has('additionalInformation') ? 'has-error' : ''); ?>">
                            <td style="width:30%">Additional Comments</td>
                            <td>
                              <input class="form-control" type="text" id="additionalInformation"
                              name="additionalInformation" size="27" style="width:100%!important" value="<?php echo e($productCatalog->additional_information); ?>" required>
                              <span class="text-danger"><?php echo e($errors->first('additionalInformation')); ?></span>
                            </td>
                        </tr>
                      </table>

                      <button class="btn btn-primary" type="submit">Update Product</button>

                   </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('loadDynamicProductDetails'); ?>

  <script type="text/javascript">
      $(document).ready(function() {

        $(".genericFeaturesTbl").on("click", ".ibtnAdd", function (event) {

            var featureType = $(this).closest("table").attr('id');
            var newRow = $("<tr>");
            var cols = "";
            cols += "<td style='width:15%;'><select class='form-control' name='" + featureType + "Status[]' value='<?php echo e(old('status')); ?>' required><option selected='selected'>Enable</option><option>Disable</option></select></td>";
            cols += "<td style='width:70%;'><input class='form-control' type='text' name='" + featureType + "FeatureText[]' value='N/A' required></td>";
            cols += "<td><p class='ibtnAdd btn btn-md btn-primary'>Add</p><p class='ibtnDel btn btn-md btn-danger' style='float:right;'>Delete</p></td>";
            newRow.append(cols);
            $(this).closest("tr").after(newRow);
        });

        $(".genericFeaturesTbl").on("click", ".ibtnDel", function (event) {

            var tableLength = $(this).closest("table").find("tr").length - 1;
            if(tableLength > 1) {
              $(this).closest("tr").remove();
            }
        });
      });
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>