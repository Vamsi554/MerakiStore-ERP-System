<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Tasks | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Task Management </h3>
            </div>

            <div class="box-body">
               <div class="row">
                   <div class="col-md-12">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Task Details </h4>
                           <tr>
                               <td style="width:30%">Assign To</td>
                               <td>
                                 <?php echo e($task->issued_to); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Assignee</td>
                               <td>
                                 <?php echo e($task->issuer); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Client</td>
                               <td>
                                 <?php echo e($task->client); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Subject</td>
                               <td>
                                 <?php echo e($task->subject); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Category</td>
                               <td>
                                 <?php echo e($task->category); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Description</td>
                               <td>
                                 <?php echo e($task->description); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Priority</td>
                               <td>
                                 <?php echo e($task->priority); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">Start Date</td>
                               <td>
                                 <?php echo e(date('d-M-Y', strtotime($task->start_dttm))); ?>

                               </td>
                           </tr>
                           <tr>
                               <td style="width:30%">End Date</td>
                               <td>
                                 <?php echo e(date('d-M-Y', strtotime($task->end_dttm))); ?>

                               </td>
                           </tr>
                      </table>

                      <?php if(count($taskNotes) > 0): ?>
                        <b class="timeline-body"> Comments </b>
                        <br><br>
                        <ul>
                        <?php $__currentLoopData = $taskNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <b> On <?php echo e($commentLine->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>, Mr. <?php echo e($commentLine->user_name); ?> Added : </b> <?php echo e($commentLine->notes); ?></li>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      <?php endif; ?>

                      <?php if($task->status != 'Completed'): ?>
                        <form method="POST" action="<?php echo e(URL::to('/')); ?>//meraki/tasks/submit/approval/<?php echo e($task->id); ?>" onsubmit="return confirm('Do You Really Want To Submit the Task for Approval?');">
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <button class="btn btn-warning ml-2" type="submit">SUBMIT FOR APPROVAL</button>
                        </form>
                      <?php endif; ?>

                   </div>
                 </div>
               </div>
             </div>
           </div>
         </section>
       </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>