<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        All Orders
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Admin Orders | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Order Details</th>
                  <th>Vendor Purchase Orders</th>
                  <th>Customer Payment Receipts</th>
                  <th>Proforma Invoice</th>
                  <th>Delivery Challan</th>
                  <th>Invoice</th>
                  <th>View</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <ul class="list-group">
                        <li class="list-group-item list-group-item-success"><?php echo e($order->orderDetails); ?></li>
                      </ul>
                    </td>
                    <td>
                      <a href="/order/admin/purchaseOrder/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-warning ml-2">Create P.O </a>
                    </td>
                    <td>
                      <a href="/order/admin/paymentReceipt/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-info ml-2">Generate Receipt</a>
                    </td>
                    <td>
                      <a href="/order/admin/proformaInvoice/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2">Generate Proforma</a>
                    </td>
                    <td>
                      <a href="/order/admin/deliveryChallan/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-info ml-2">Generate D.C </a>
                    </td>
                    <td>
                      <a href="/order/admin/invoice/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2">Generate Invoice </a>
                    </td>
                    <td>
                      <a href="/order/admin/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-warning ml-2">View</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>