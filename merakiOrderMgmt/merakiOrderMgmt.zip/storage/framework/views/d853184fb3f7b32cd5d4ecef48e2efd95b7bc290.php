<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Tasks
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tasks | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Task ID</th>
                  <th>Task Title</th>
                  <th>Task Body</th>
                  <th>Task Creation DateTime</th>
                  <th>Task Edit</th>
                  <th>Task Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($task->id); ?></td>
                    <td><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->body); ?></td>
                    <td><?php echo e($task->created_at); ?></td>
                    <td>
                      <a href="/task/updateTask/<?php echo e($task->id); ?>" class="btn btn-warning ml-2">Update</a>
                    </td>
                    <td>
                      <form action="/task/deleteTask/<?php echo e($task->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-danger" type="submit">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <a href="<?php echo e(url('/task/createTask')); ?>" class="btn btn-primary ml-2">Add New Task</a>

    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>