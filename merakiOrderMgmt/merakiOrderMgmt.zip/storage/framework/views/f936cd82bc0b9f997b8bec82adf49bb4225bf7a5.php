<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Invoice #<?php echo e($id); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <table class="table table-bordered">
        <tr>
          MERAKI ENTERPRISES
        </tr>
        <tr style="background-color: #Ffce37;">
          <span style="background-color: #Ffce37;">DELIVERY CHALLAN</span>
        </tr>
      </table>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>