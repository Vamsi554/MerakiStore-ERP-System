<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Customer Payment Receipt #<?php echo e($customerPayments[0]->cust_pay_code); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              D.No:101, Near SR Club, Sri Nagar Colony <br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->

      <div class="row invoice-info">
        <center><strong>PAYMENT RECEIPT</strong></center>
        <br><br>
        <div class="col-sm-5 invoice-col">
          Received From
          <address>
            <strong><?php echo e($customerName); ?> </strong><br>
            <?php
              $addressArr = explode(",", $order->billingAddress);
            ?>
            <?php for($i=0; $i<count($addressArr); $i++): ?>
              <?php echo e($addressArr[$i]); ?> <br>
            <?php endfor; ?>
            </i></b>
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          Paid To
          <address>
            <strong>Mr.Abhilash Gali</strong><br>
            Meraki Enterprises<br>
            Hyderabad, Telangana<br>
            Tel: 040-48554470, 9000909109<br>
            Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-3 invoice-col">
          <b>Date: </b> <?php echo e($customerPayments->last()->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y")); ?> <br>
          <b>Reference No: </b> <?php echo e($order->documentNumber); ?> <br>
          <b>Receipt No: </b> <?php echo e($customerPayments[0]->cust_pay_code); ?> <br>
          <br>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr bgcolor="#Ffce37;">
              <th>SNo</th>
              <th>Description</th>
              <th>HSN</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Taxable Amount</th>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <th>CGST</th>
                <th>SGST</th>
              <?php else: ?>
                <th>IGST</th>
              <?php endif; ?>
              <th>Total Amount</th>
            </tr>
            </thead>
            <tbody>
              <?php
                $m = 1;
              ?>
            <?php $__currentLoopData = $enquiryQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quoteEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($m++); ?></td>
              <td><?php echo e($quoteEntry->product_description); ?></td>
              <td><?php echo e($quoteEntry->hsn); ?></td>
              <td><?php echo e($quoteEntry->quantity); ?> Units</td>
              <td>Rs.<?php echo e($quoteEntry->cost_per_unit); ?>/-</td>
              <?php
                $totAmt = $quoteEntry->cost_per_unit * $quoteEntry->quantity;
                $taxPer = $quoteEntry->gst_tax;
                $indvTaxPer = $quoteEntry->gst_tax/2.0;
                $cgst = $totAmt * $indvTaxPer/100.0;
                $sgst = $totAmt * $indvTaxPer/100.0;
                $igst = $cgst + $sgst;
                $finalAmount = $totAmt + $cgst + $sgst;
              ?>
              <td>Rs.<?php echo e($totAmt); ?>/-</td>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <td>Rs.<?php echo e($cgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
                <td>Rs.<?php echo e($sgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
              <?php else: ?>
                <td>Rs.<?php echo e($igst); ?>/- <sub><b>(<?php echo e($taxPer); ?>%)</b></sub></td>
              <?php endif; ?>
              <td>Rs.<?php echo e($finalAmount); ?>/-</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td><td></td><td></td><td></td><td></td><td></td>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <td></td>
              <?php endif; ?>
              <td><strong>Grand Total</strong></td>
              <td><strong>Rs.<?php echo e($order->orderAmount); ?>/-</strong></td></tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <strong>Payment Details</strong><br>
      <br>
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr>
              <th style="text-align:center;">Cash</th>
              <th style="text-align:center;">Cheque</th>
              <th style="text-align:center;">Online</th>
              <th style="text-align:center;">Total Amount (Cash/Cheque/Online)</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $customerPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cusPay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="width:30%;">
                  <b>Cash Amount</b> : <?php echo e($cusPay->cash_amount); ?> <br>
                  <?php if($cusPay->payment_date != null): ?>
                    <b>Payment Date</b> : <?php echo e(date('d-M-Y', strtotime($cusPay->payment_date))); ?> <br>
                  <?php endif; ?>
                  <b>Received From</b> : <?php echo e($cusPay->received_from_person); ?> <br>
                </td>
                <td style="width:30%;">
                  <b>Bank Name</b> : <?php echo e($cusPay->bank_cheque); ?> <br>
                  <b>Cheque Number</b> : <?php echo e(Crypt::decryptString($cusPay->cheque_number)); ?> <br>
                  <b>Cheque Amount</b> : <?php echo e($cusPay->cheque_amount); ?> <br>
                  <?php if($cusPay->cheque_date != null): ?>
                    <b>Cheque Date</b> : <?php echo e(date('d-M-Y', strtotime($cusPay->cheque_date))); ?> <br>
                  <?php endif; ?>
                </td>
                <td style="width:30%;">
                  <b>Transaction ID</b> : <?php echo e(Crypt::decryptString($cusPay->transaction_id)); ?> <br>
                  <b>Bank Name</b> :  <?php echo e($cusPay->bank_name); ?> <br>
                  <b>Customer Account Number</b> : <?php echo e(Crypt::decryptString($cusPay->customer_from_account_number)); ?> <br>
                  <b>Meraki Account Number</b> : <?php echo e(Crypt::decryptString($cusPay->meraki_to_account_number)); ?> <br>
                  <b>Transaction Amount</b> : <?php echo e($cusPay->transaction_amount); ?> <br>
                  <?php if($cusPay->transaction_date != null): ?>
                    <b>Transaction Date</b> : <?php echo e(date('d-M-Y', strtotime($cusPay->transaction_date))); ?> <br>
                  <?php endif; ?>
                </td>
                <td><?php echo e($cusPay->total_payment_amount); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <strong>Official Stamp: </strong><br>


      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      html { overflow-x: hidden; }

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {
          -webkit-print-color-adjust: exact !important;
          margin: 0mm;
          size: auto;
        }
      }

  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>