<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Order | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Order - <span style="color:#Ffce37;"><b><?php echo e($order->documentNumber); ?>, <?php echo e($order->orderStatus); ?></b></span></h3>
            </div>

            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>

               <div class="row">
                 <div class="col-md-5">
                   <table class="table table-bordered table-striped">
                     <h4 class="box-title"> Basic Details </h4>
                       <tr>
                           <td style="width:30%">Email Address</td>
                           <td>
                             <?php echo e($order->email); ?>

                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Document Number</td>
                           <td>
                             <b><?php echo e($order->documentNumber); ?></b>
                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Creation Date</td>
                           <td>
                             <?php echo e($order->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Modified Date</td>
                           <td>
                             <?php echo e($order->updated_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                           </td>
                       </tr>
                    </table>
                 </div>
                 <div class="col-md-7">
                   <table class="table table-bordered table-striped">
                     <h4 class="box-title"> Order Details </h4>
                       <tr>
                           <td style="width:30%">Expected Delivery</td>
                           <td>
                             <b><?php echo e(date('d-M-Y', strtotime($order->expectedDelivery))); ?></b>
                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Order Amount</td>
                           <td>
                             <b>Rs.<?php echo e($order->orderAmount); ?>/-</b>
                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Order Details</td>
                           <td>
                             <?php echo e($order->orderDetails); ?>

                           </td>
                       </tr>
                       <tr>
                           <td style="width:30%">Order Summary</td>
                           <td>
                             <?php echo e($order->orderSummary); ?>

                           </td>
                       </tr>
                    </table>
                 </div>
               </div>

               <table class="table table-bordered table-striped">
                 <h4 class="box-title"> Requirement Details </h4>
                   <input type="hidden" id="reqCount" name="reqCount">
                   <table class="table table-bordered table-hover" id="tab_logic">
                     <thead>
                       <tr>
                         <th class="text-center">Product Details</th>
                         <th class="text-center">Art Work Design</th>
                         <th class="text-center">Customization Details</th>
                         <th class="text-center">Additional Details</th>
                       </tr>
                     </thead>
                     <tbody>
                     <?php $i = 0; ?>
                       <?php $__currentLoopData = $enquiryRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiryReq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr id='addr<?php echo $i; ?>'>
                           <td style="width:22%;">
                             <b>Category</b> : <?php echo e($enquiryReq->product_category); ?> <br><br>

                             <b>Description</b> : <?php echo e($enquiryReq->product_description); ?> <br><br>

                             <?php if($enquiryReq->status == 'Approved'): ?>
                               <span class="label label-success">Approved</span>
                             <?php elseif($enquiryReq->status == 'Hold'): ?>
                               <span class="label label-warning">Hold</span>
                             <?php else: ?>
                               <span class="label label-danger">Cancel</span>
                             <?php endif; ?>
                           </td>
                           <td style="width:15%;">
                             <?php echo e($enquiryReq->art_work_notes); ?>

                           </td>
                           <td style="width: 32%;">
                             <b>Product Features</b>
                             <ul>
                               <li>Product Style : <?php if($enquiryReq->product_style == '0' || $enquiryReq->product_style == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->product_style); ?> <?php endif; ?></li>
                               <li>Material : <?php if($enquiryReq->material == '0' || $enquiryReq->material == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->material); ?> <?php endif; ?></li>
                               <li>Quantity : <?php if($enquiryReq->quantity == '0' || $enquiryReq->quantity == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quantity); ?> <?php endif; ?></li>
                               <li>Quality : <?php if($enquiryReq->quality == '0' || $enquiryReq->quality == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quality); ?> <?php endif; ?></li>
                               <li>Fabric: <?php if($enquiryReq->fabric == '0' || $enquiryReq->fabric == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->fabric); ?> <?php endif; ?></li>
                               <?php if($enquiryReq->additional_features != '0' && $enquiryReq->additional_features != null && $enquiryReq->additional_features != 'N/A'): ?>
                                 <li><?php echo e($enquiryReq->additional_features); ?><li>
                               <?php endif; ?>
                             </ul>

                             <b>Product Customizations</b>
                             <ul>
                               <li>Colour: <?php if($enquiryReq->colour == '0' || $enquiryReq->colour == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->colour); ?> <?php endif; ?></li>
                               <li>Print Methods: <?php if($enquiryReq->print_methods == '0' || $enquiryReq->print_methods == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_methods); ?> <?php endif; ?></li>
                               <li>Print Placements: <?php if($enquiryReq->print_placements == '0' || $enquiryReq->print_placements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_placements); ?> <?php endif; ?></li>
                               <li>Print Area: <?php if($enquiryReq->print_area == '0' || $enquiryReq->print_area == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_area); ?> <?php endif; ?></li>
                               <li>Measurements: <?php if($enquiryReq->measurements == '0' || $enquiryReq->measurements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->measurements); ?> <?php endif; ?></li>
                               <?php if($enquiryReq->additional_customizations != '0' && $enquiryReq->additional_customizations != null && $enquiryReq->additional_customizations != 'N/A'): ?>
                                 <li><?php echo e($enquiryReq->additional_customizations); ?><li>
                               <?php endif; ?>
                             </ul>
                           </td>
                           <td>
                             <b>Finishing</b> : <?php if($enquiryReq->finishing == '0' || $enquiryReq->finishing == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->finishing); ?> <?php endif; ?> <br><br>
                             <b>Packaging</b> : <?php if($enquiryReq->packaging == '0' || $enquiryReq->packaging == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->packaging); ?> <?php endif; ?> <br><br>
                             <b>Inclusive</b> : <?php if($enquiryReq->inclusive == '0' || $enquiryReq->inclusive == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->inclusive); ?> <?php endif; ?> <br><br>
                             <b>Exclusive</b> : <?php if($enquiryReq->exclusive == '0' || $enquiryReq->exclusive == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->exclusive); ?> <?php endif; ?> <br><br>
                           </td>
                         </tr>
                         <?php $i++; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                   </table>
               </table>

               <table class="table table-bordered table-striped">
                 <h4 class="box-title"> Billing Details </h4>
                   <tr>
                       <td style="width:30%">Billing Address</td>
                       <td>
                         <b><?php echo e($order->billingAddress); ?></b>
                       </td>
                   </tr>
                </table>

                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> Shipment Details </h4>
                     <tr>
                         <td style="width:30%">Shipment Address</td>
                         <td>
                           <?php echo e($order->shipmentAddress); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Contact Person at Shipment</td>
                         <td>
                           <?php echo e($order->contactPersonAtShipment); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Contact Number at Shipment</td>
                         <td>
                           <?php echo e($order->contactNumberAtShipment); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Concerned Lead</td>
                         <td>
                           <?php echo e($order->concernedLead); ?>

                         </td>
                     </tr>
                  </table>

              <?php if($order->orderStatus != 'ORDER COMPLETED'): ?>

                  <table class="table table-bordered table-striped" id="orderStatusUpdate">
                    <h4 class="box-title"> Status Updates </h4> <br>
                      <ul>
                      <?php $__currentLoopData = $orderStatusUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusUpdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <b> On <?php echo e($statusUpdate->creation_dttm); ?>, Mr. <?php echo e($statusUpdate->user); ?> Added : </b> <?php echo e($statusUpdate->comments); ?></li> <br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>

                      <a href="#addStatusUpdateModal" class="btn btn-primary ml-2" data-toggle="modal"> Add Update </a>

                      <div class="modal fade" id="addStatusUpdateModal" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/statusUpdate/save/<?php echo e($order->id); ?>" autocomplete="off">
                              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title"> Add Status Update To This Order </h4>
                              </div>
                              <div class="modal-body">
                                <b>Document Number : </b> <?php echo e($order->documentNumber); ?>

                                <br><br>
                                <b>Summary : </b> <?php echo e($order->orderDetails); ?>

                                <br><br>
                                <b>Merchandise : </b> <?php echo e($order->orderSummary); ?>

                                <br><br>
                                <b>Status : </b> <?php echo e($order->orderStatus); ?>

                                <br><br>
                                <b>Note : </b> <br><br>
                                <textarea rows="4" cols="50" class="form-control" type="text" id="orderStatusUpdate"
                                name="orderStatusUpdate" size="100" style="width:100%!important"
                                value="<?php echo e(old('sampleDetailsComments')); ?>" required></textarea>
                                <br>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                   </table>
                 <?php endif; ?>

                  <?php if($order->orderStatus == 'ORDER DELIVERED' || $order->orderStatus == 'ORDER COMPLETED'): ?>
                  <table class="table table-bordered table-striped">
                    <h4 class="box-title"> Post-Order Delivery </h4>
                    <tr>
                        <td style="width:30%">Client Feedback</td>
                        <td>
                          <?php echo e($order->clientFeedback); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Comments</td>
                        <td>
                          <?php echo e($order->postOrderDeliveryComments); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">All Documents Verified with Client & Manager</td>
                        <td>
                          Yes
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Concerned Lead Signature</td>
                        <td>
                          <?php echo e($order->concernedLead); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Manager Signature</td>
                        <td>
                          <?php echo e($enquiry->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Admin Signature</td>
                        <td>
                          <?php echo e($order->concernedLead); ?>

                        </td>
                    </tr>
                  </table>
                <?php endif; ?>

                <table class="table table-bordered table-striped">
                  <?php if($order->proformaInvoiceNumber != '///////////////'): ?>
                    <h4 class="box-title"> Order Documents </h4>
                  <?php endif; ?>
                  <?php if($order->purchaseOrderNumber != '///////////////'): ?>
                    <tr>
                        <td> Purchase Order </td>
                        <td>
                          <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" target="_blank"> View Purchase Order </a>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if($order->proformaInvoiceNumber != '///////////////'): ?>
                    <tr>
                        <td> Proforma Invoice </td>
                        <td>
                          <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/proformaInvoice/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" target="_blank">View Proforma Invoice</a>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if($order->techPackNumber != '///////////////'): ?>
                    <tr>
                        <td style="width:30%"> Tech Pack </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/techPack/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" style="width: 30%;" target="_blank">View Tech Pack</a>
                        </td>
                    </tr>
                  <?php endif; ?>

                  <?php if(count($order->customerPayments()->get()) > 0): ?>
                    <tr>
                        <td> Customer Payments </td>
                        <?php
                          $customerPayments = $order->customerPayments()->select('cust_pay_code')->distinct()->get();
                        ?>
                        <td>
                        <?php $__currentLoopData = $customerPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/paymentReceipt/display/<?php echo e($order->id); ?>/<?php echo e($payment->cust_pay_code); ?>"
                              class="btn btn-success ml-2" target="_blank"><?php echo e($payment->cust_pay_code); ?></a>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if(count($order->vendorPayments()->get()) > 0): ?>
                    <tr>
                        <td> Vendor Payments </td>
                        <td>
                          <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/admin/vendor/paymentReceipt/display/<?php echo e($order->id); ?>" class="btn btn-success ml-2" target="_blank">View Vendor Payments</a>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if(count($order->deliveryChallans()->get()) > 0): ?>
                    <tr>
                        <td> Delivery Challan </td>
                        <?php
                          $orderDeliveryChallans = $order->deliveryChallans()->select('delivery_challan_code')->distinct()->get();
                        ?>
                        <td>
                        <?php $__currentLoopData = $orderDeliveryChallans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryChallan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/deliveryChallan/display/<?php echo e($order->id); ?>/<?php echo e($deliveryChallan->delivery_challan_code); ?>" class="btn btn-success ml-2" target="_blank">DC- <?php echo e($deliveryChallan->delivery_challan_code); ?></a>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if($order->invoiceDate != null): ?>
                    <tr>
                        <td> Tax Invoice </td>
                        <td>
                          <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/invoice/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" target="_blank">View Tax Invoice</a>
                        </td>
                    </tr>
                  <?php endif; ?>
                </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>