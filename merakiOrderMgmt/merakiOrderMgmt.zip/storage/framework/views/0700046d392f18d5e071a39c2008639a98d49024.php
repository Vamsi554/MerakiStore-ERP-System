<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Invoice #<?php echo e($id); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              2-18-86, Ambedkar Nagar, Uppal<br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->

      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          Invoice To
          <address>
            <strong>Mr.Sudhakar</strong><br>
            Oracle India Private Limited<br>
            Ground to 7th floor, Tower C<br>
            Ananth Info Park<br>
            Hitech City, Hyderabad, Telangana</i></b><br>
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          Ship To
          <address>
            <strong>Oracle India Private Limited</strong><br>
            Ground to 7th floor, Tower C<br>
            Ananth Info Park<br>
            Hitech City, Hyderabad, Telangana<br>
            Phone: 9090909090
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <b>Date: </b> 22/08/2018 <br>
          <br>
          <b>Challan No: </b> 001 <br>
          <b>GSTIN: </b> 36BOPPG4920P1ZD <br>
          <b>Purchase Order No: </b> IN210011119 <br>
          <b>Client GST No: </b> 36BOPPG4920P1ZD <br>
          <br>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr style="background-color: #Ffce37 !important">
              <th>S No</th>
              <th>Description</th>
              <th>HSN</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>CGST</th>
              <th>SGST</th>
              <th>Total Value</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>01</td>
              <td>Hoodies</td>
              <td>6109</td>
              <td>115 Pcs</td>
              <td>Rs.1200/-</td>
              <td>Rs.30/-</td>
              <td>Rs.30/-</td>
              <td>Rs.1,44,900/-</td>
            </tr>
            <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
            <tr bgcolor="#Ffce37">
              <td></td><td></td><td></td><td></td><td></td><td></td>
              <td><strong>Grand Total</strong></td>
              <td><strong>Rs.1,44,900/-</strong></td></tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <strong>Rupees In Words: </strong> One lakh forty four thousand nine hundred only.<br>
      <br>
      <strong>Terms and Conditions</strong><br>
      <br>
      <ul>
        <li>Our responsibility ceases as soon as goods delivered in your premises.</li>
        <li>We will recognize only official receipt.</li>
        <li>Goods once sold cannot be returned or exchanged.</li>
        <li>Full Payment must be made to us on the presentation of the Invoice otherwise interest will be charged @18% P.A.</li>
        <li>All disputes shall be subjected to Hyderabad jurisdiction only.</li>
        <li>We reserved to ourselves the right to demand payment of this bill any time before due date.</li>
        <li>All cheques /drafts to be made in favour of <b>"MERAKII ENTERPRISES"</b>, Payable at Hyderabad.</li>
        <li>Mention the Invoice No at the back of your cheque / draft.</li>
      </ul>

      <br>

      <div class="row">
        <div class="col-xs-4">
          <p class="lead">Bank Details</p>
          <p><strong>A/C Holder:</strong> Merakii Enterprises</p>
          <p><strong>A/C No:</strong> 50200031105382 </p>
          <p><strong>Bank:</strong> HDFC </p>
          <p><strong>Branch:</strong> Srinagar colony, Hyderabad</p>
          <p><strong>IFSC Code:</strong> HDFC0001554 </p>
        </div>
        <div class="col-xs-4">
          <p class="lead">GSTIN: 36BOPPG4920P1ZD </p>
          <p>I/We hereby certify that our
            registration certificate under
            the Telangana value added tax
            Act.2014.</p>
        </div>

        <!-- accepted payments column -->
        <div class="col-xs-4">
          <p class="lead">Payment Methods</p>
          <img src="../../dist/img/credit/visa.png" alt="Visa">
          <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
          <img src="../../dist/img/credit/paypal2.png" alt="Paypal">
          <p style="padding-top: 20px;"> Cash On Delivery </p>
        </div>
      </div>
      <!-- /.row -->

      <br><br>
      <footer class="text-center mt-5" >
        Copyright &copy; 2018 Meraki Stores. All rights reserved.
      </footer>

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {-webkit-print-color-adjust: exact !important;}
      }

  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>