<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Vendors
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Vendors | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Vendor Code</th>
                  <th>Vendor Name</th>
                  <th>Vendor Phone</th>
                  <th>Vendor Company</th>
                  <th>Location</th>
                  <th>Update</th>
                  <th>View</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($vendor->vendor_code); ?></td>
                    <td><?php echo e($vendor->vendor_name); ?></td>
                    <td><?php echo e($vendor->vendor_phone); ?></td>
                    <td><?php echo e($vendor->vendor_company); ?></td>
                    <td><?php echo e($vendor->city); ?></td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/meraki/vendors/updateVendor/<?php echo e($vendor->id); ?>" class="btn btn-warning ml-2">Update</a>
                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/meraki/vendors/displayVendor/<?php echo e($vendor->id); ?>" class="btn btn-info ml-2">View</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <a href="<?php echo e(URL::to('/')); ?>/meraki/vendors/addVendor" class="btn btn-primary ml-2">Add Vendor</a>

    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>