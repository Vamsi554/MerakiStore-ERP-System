<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Tech Pack #<?php echo e($order->techPackNumber); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              D.No:101, Near SR Club, Sri Nagar Colony<br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
      </div>

      <div class="row invoice-info">
        <div class="col-xs-12">
          <h4 class="text-center"><strong> TECH PACK </strong></h4>
          <p style="float:right"><strong>Date:</strong> <?php echo e(date("d-M-Y", strtotime($enquiryRequirements[0]->tech_pack_date))); ?></p>
          <strong>To,</strong><br>
          <?php echo e($enquiry->name); ?>,<br>
          <?php echo e($enquiry->organizationName); ?>,<br>
          <?php echo e($enquiry->eventName); ?>,<br>
          <?php echo e($enquiry->eventPlace); ?>.<br>
          <br>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <strong>Kind Attn: </strong> Mr/Mrs. <?php echo e($enquiry->name); ?>, <?php echo e($enquiry->designation); ?> <br>
          Mob. No. <?php echo e($enquiry->phone); ?> <br>
          <br>
          <strong>Sub: <?php echo e($enquiry->eventName); ?> Merchandise Kit Tech Pack Details.</strong><br>
          <br>
          <p> Dear Sir/Madam, <br><br>

              Merakii is a one stop destination for all your Merchandise needs be it for college or corporate events.
              With the objective of providing our customers with a range of customised products, our Team at Merakii work
              round the clock striving for perfection and punctuality, while also ensuring affordable pricing!
              <br><br>
              With reference to the requirement mentioned from your side, please go through the below tech pack details for the order.
          </p>

          <table class="table table-bordered table-striped">
            <thead>
              <tr bgcolor="#Ffce37;">
                <th>Merchandise</th>
                <th>Technical Details</th>
                <th>Estimated Delivery</th>
                <th>BreakUp Details</th>
              </tr>
            </thead>
            <tbody>
            <?php for($f=0; $f<count($enquiryRequirements); $f++): ?>
              <tr>
                <td><?php echo e($enquiryRequirements[$f]->product_description); ?></td>
                <td>
                  <?php
                    $enquiryReq = $enquiryRequirements[$f];
                  ?>
                  <b>Product Features</b>
                  <ul>
                    <li>Product Style : <?php if($enquiryReq->product_style == '0' || $enquiryReq->product_style == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->product_style); ?> <?php endif; ?></li>
                    <li>Material : <?php if($enquiryReq->material == '0' || $enquiryReq->material == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->material); ?> <?php endif; ?></li>
                    <li>Quantity : <?php if($enquiryReq->quantity == '0' || $enquiryReq->quantity == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quantity); ?> <?php endif; ?></li>
                    <li>Quality : <?php if($enquiryReq->quality == '0' || $enquiryReq->quality == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quality); ?> <?php endif; ?></li>
                    <li>Fabric: <?php if($enquiryReq->fabric == '0' || $enquiryReq->fabric == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->fabric); ?> <?php endif; ?></li>
                    <?php if($enquiryReq->additional_features != '0' && $enquiryReq->additional_features != null && $enquiryReq->additional_features != 'N/A'): ?>
                      <li><?php echo e($enquiryReq->additional_features); ?><li>
                    <?php endif; ?>
                  </ul>

                  <b>Product Customizations</b>
                  <ul>
                    <li>Colour: <?php if($enquiryReq->colour == '0' || $enquiryReq->colour == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->colour); ?> <?php endif; ?></li>
                    <li>Print Methods: <?php if($enquiryReq->print_methods == '0' || $enquiryReq->print_methods == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_methods); ?> <?php endif; ?></li>
                    <li>Print Placements: <?php if($enquiryReq->print_placements == '0' || $enquiryReq->print_placements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_placements); ?> <?php endif; ?></li>
                    <li>Print Area: <?php if($enquiryReq->print_area == '0' || $enquiryReq->print_area == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_area); ?> <?php endif; ?></li>
                    <li>Measurements: <?php if($enquiryReq->measurements == '0' || $enquiryReq->measurements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->measurements); ?> <?php endif; ?></li>
                    <?php if($enquiryReq->additional_customizations != '0' && $enquiryReq->additional_customizations != null && $enquiryReq->additional_customizations != 'N/A'): ?>
                      <li><?php echo e($enquiryReq->additional_customizations); ?><li>
                    <?php endif; ?>
                  </ul>
                </td>
                <td><?php echo e(date("d-M-Y", strtotime($enquiryRequirements[$f]->est_delivery))); ?></td>
                <?php
                  $breakUpDtlsArr = explode(",", $enquiryRequirements[$f]->breakup_details);
                ?>
                <td style="width:25%;">
                  <ul>
                    <?php for($m=0; $m<count($breakUpDtlsArr); $m++): ?>
                      <li><?php echo e($breakUpDtlsArr[$m]); ?></li>
                    <?php endfor; ?>
                  </ul>
                </td>
              </tr>
            <?php endfor; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">

          With Regards<br>
          <b>Meraki Enterprises</b>
          <br><br>
          (Abhilash Gali)<br>
          Manager-Sales Department<br>
          +91 9000 909 109<br>
        </div>
      </div>


      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      td {
        padding-left: 10px;
      }

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm 0mm 0mm 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {-webkit-print-color-adjust: exact !important;}

        .headerContent {
          display: block;
        }
      }

      @media  screen {

        .headerContent {
          display: none;
        }
      }
  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>