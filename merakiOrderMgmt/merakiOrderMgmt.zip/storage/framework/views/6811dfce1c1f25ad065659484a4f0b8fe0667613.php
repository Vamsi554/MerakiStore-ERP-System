<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Vendor Payment Receipt #<?php echo e($vendorPayments[0]->order_id); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              D.No:101, Near SR Club, Sri Nagar Colony <br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->

      <div class="row invoice-info">
        <center><strong>VENDOR PAYMENT DETAILS</strong></center>
        <br><br>

        <b>Vendor Name</b> : <?php echo e($vendorPoLink[0]->vendor_code); ?> <br><br>
        <b>Purchase Order Number</b> : <?php echo e($vendorPoLink[0]->purchase_order_code); ?> <br><br>
        <b>Vendor Payment Amount</b> : <?php echo e($vendorPoLink[0]->vendor_payment_amount); ?> <br><br>

        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table class="table table-bordered">
              <thead>
              <tr style="background-color: #Ffce37 !important">
                <th style="text-align:center;">Cash</th>
                <th style="text-align:center;">Cheque</th>
                <th style="text-align:center;">Online</th>
                <th style="text-align:center;">Total Amount (Cash/Cheque/Online)</th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $vendorPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venPay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td style="width:30%;">
                    <b>Cash Amount</b> : <?php echo e($venPay->cash_amount); ?> <br>
                    <?php if($venPay->payment_date != null): ?>
                      <b>Payment Date</b> : <?php echo e(date('d-M-Y', strtotime($venPay->payment_date))); ?> <br>
                    <?php endif; ?>
                    <b>Paid To</b> : <?php echo e($venPay->paid_to_person); ?> <br>
                  </td>
                  <td style="width:30%;">
                    <b>Bank Name</b> : <?php echo e($venPay->bank_cheque); ?> <br>
                    <b>Cheque Number</b> : <?php echo e(Crypt::decryptString($venPay->cheque_number)); ?> <br>
                    <b>Cheque Amount</b> : <?php echo e($venPay->cheque_amount); ?> <br>
                    <?php if($venPay->cheque_date != null): ?>
                      <b>Cheque Date</b> : <?php echo e(date('d-M-Y', strtotime($venPay->cheque_date))); ?> <br>
                    <?php endif; ?>
                  </td>
                  <td style="width:30%;">
                    <b>Transaction ID</b> : <?php echo e(Crypt::decryptString($venPay->transaction_id)); ?> <br>
                    <b>Bank Name</b> :  <?php echo e($venPay->bank_name); ?> <br>
                    <b>Meraki Account Number</b> : <?php echo e(Crypt::decryptString($venPay->meraki_from_account_number)); ?> <br>
                    <b>Vendor Account Number</b> : <?php echo e(Crypt::decryptString($venPay->vendor_to_account_number)); ?> <br>
                    <b>Transaction Amount</b> : <?php echo e($venPay->transaction_amount); ?> <br>
                    <?php if($venPay->transaction_date != null): ?>
                      <b>Transaction Date</b> : <?php echo e(date('d-M-Y', strtotime($venPay->transaction_date))); ?> <br>
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($venPay->total_payment_amount); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      html { overflow-x: hidden; }

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {
          -webkit-print-color-adjust: exact !important;
          margin: 0mm;
          size: auto;
        }
      }

  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>