<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Proforma Invoice #<?php echo e($order->proformaInvoiceNumber); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              D.No:101, Near SR Club, Sri Nagar Colony<br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->

      <div class="row invoice-info">
        <h4 class="text-center"><strong> PROFORMA INVOICE </strong></h4>
        <div class="col-sm-4 invoice-col">
          <b>Bill To</b>
          <address>
            <?php
              $billAddrArr = explode(",", $order->billingAddress);
            ?>
            <?php for($i=0; $i<count($billAddrArr); $i++): ?>
              <?php echo e($billAddrArr[$i]); ?> <br>
            <?php endfor; ?>
            </i></b><br>
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-5 invoice-col">
          <b>Proforma No: </b> <?php echo e($order->proformaInvoiceNumber); ?><br>
          <b>Date: </b> <?php echo e(\Carbon\Carbon::now("Asia/Kolkata")->format("d-M-Y")); ?> <br>
          <b>Reference No: </b> <?php echo e($order->documentNumber); ?><br>
          <b>Due Date: </b> <?php echo e(\Carbon\Carbon::now("Asia/Kolkata")->format("d-M-Y")); ?> <br>
        </div>
        <!-- /.col -->
        <div class="col-sm-3 invoice-col">
          <b>GSTIN: </b> 36BOPPG4920P1ZD <br>
          <b>PAN: </b> BOPPG4920 <br>
          <b>Client GST No: </b> <?php echo e($order->client_gst_number); ?> <br>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr bgcolor="#Ffce37;">
              <th>SNo</th>
              <th>Description</th>
              <th>HSN</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Taxable Amount</th>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <th>CGST</th>
                <th>SGST</th>
              <?php else: ?>
                <th>IGST</th>
              <?php endif; ?>
              <th>Total Amount</th>
            </tr>
            </thead>
            <tbody>
              <?php
                $m = 1;
              ?>
            <?php $__currentLoopData = $enquiryQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quoteEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($m++); ?></td>
              <td><?php echo e($quoteEntry->product_description); ?></td>
              <td><?php echo e($quoteEntry->hsn); ?></td>
              <td><?php echo e($quoteEntry->quantity); ?> Units</td>
              <td>Rs.<?php echo e($quoteEntry->cost_per_unit); ?>/-</td>
              <?php
                $totAmt = $quoteEntry->cost_per_unit * $quoteEntry->quantity;
                $taxPer = $quoteEntry->gst_tax;
                $indvTaxPer = $quoteEntry->gst_tax/2.0;
                $cgst = $totAmt * $indvTaxPer/100.0;
                $sgst = $totAmt * $indvTaxPer/100.0;
                $igst = $cgst + $sgst;
                $finalAmount = $totAmt + $cgst + $sgst;
              ?>
              <td>Rs.<?php echo e($totAmt); ?>/-</td>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <td>Rs.<?php echo e($cgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
                <td>Rs.<?php echo e($sgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
              <?php else: ?>
                <td>Rs.<?php echo e($igst); ?>/- <sub><b>(<?php echo e($taxPer); ?>%)</b></sub></td>
              <?php endif; ?>
              <td>Rs.<?php echo e($finalAmount); ?>/-</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td><td></td><td></td><td></td><td></td><td></td>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <td></td>
              <?php endif; ?>
              <td><strong>Grand Total</strong></td>
              <td><strong>Rs.<?php echo e($order->orderAmount); ?>/-</strong></td></tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <?php if($order->advancePaymentPercentage != 0): ?>
        <?php
          $advPayAmt = $order->orderAmount * $order->advancePaymentPercentage / 100.0 ;
        ?>
        <strong>Advance To Pay (<?php echo e($order->advancePaymentPercentage); ?>%): </strong> Rs.<?php echo e($advPayAmt); ?>/-
        <span style="float:right;"><strong>Balance To Pay (<?php echo e(100 - ($order->advancePaymentPercentage)); ?>%): </strong> Rs.<?php echo e($order->orderAmount - $advPayAmt); ?>/- </span> <br>
      <?php endif; ?>

      <h4>Terms and Conditions</h4>
      <ul>
        <li>Our responsibility ceases as soon as goods delivered in your premises.</li>
        <li>We will recognize only official receipt.</li>
        <li>Goods once sold cannot be returned or exchanged.</li>
        <li>Full Payment must be made to us on the presentation of the Invoice otherwise interest will be charged @18% P.A.</li>
        <li>All disputes shall be subjected to Hyderabad jurisdiction only.</li>
        <li>We reserved to ourselves the right to demand payment of this bill any time before due date.</li>
        <li>All cheques /drafts to be made in favour of <b>"MERAKII ENTERPRISES"</b>, Payable at Hyderabad.</li>
        <li>Mention the Invoice No at the back of your cheque / draft.</li>
      </ul>

      <div class="row">
        <div class="col-xs-4">
          <p class="lead">Bank Details</p>
          <p><strong>A/C Holder:</strong> Merakii Enterprises</p>
          <p><strong>A/C No:</strong> 50200031105382 </p>
          <p><strong>Bank:</strong> HDFC </p>
          <p><strong>Branch:</strong> Srinagar colony, Hyderabad</p>
          <p><strong>IFSC Code:</strong> HDFC0001554 </p>
        </div>
        <div class="col-xs-4">
          <p class="lead">GSTIN: 36BOPPG4920P1ZD </p>
          <p>I/We hereby certify that our
            registration certificate under
            the Telangana Goods and Services Tax Act. 2017.</p>
        </div>
        <div class="col-xs-4">
          <p class="lead">Authorised Signatory</p>
        </div>
      </div>

      <?php if(count($enquiryQuote) == 1): ?>
        <br><br><br><br><br>
      <?php endif; ?>

      <?php if(count($enquiryQuote) == 2): ?>
        <br><br><br><br>
      <?php endif; ?>

      <footer class="text-center">
        Copyright &copy; 2018 Meraki Stores. All rights reserved.
      </footer>

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm 0mm 0mm 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {-webkit-print-color-adjust: exact !important;}

      }

  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>