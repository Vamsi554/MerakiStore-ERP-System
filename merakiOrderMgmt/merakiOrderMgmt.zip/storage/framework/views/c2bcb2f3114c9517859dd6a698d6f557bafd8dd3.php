<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Order | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Order - <span style="color:#Ffce37;"><b><?php echo e($order->documentNumber); ?>, <?php echo e($order->orderStatus); ?></b></span></h3>
            </div>

            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>

               <?php if(Session::has('error')): ?>
                   <div class="alert alert-danger" style="display: inline-block;">
                      <?php echo e(Session::get('error')); ?>

                         <?php
                          Session::forget('error');
                         ?>
                    </div>
                <?php endif; ?>

                <div class="row">
                  <div class="col-md-5">
                    <table class="table table-bordered table-striped">
                      <h4 class="box-title"> Basic Details </h4>
                        <tr>
                            <td style="width:30%">Email Address</td>
                            <td>
                              <?php echo e($order->email); ?>

                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Document Number</td>
                            <td>
                              <b><?php echo e($order->documentNumber); ?></b>
                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Creation Date</td>
                            <td>
                              <?php echo e($order->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                            </td>
                        </tr>
                        <tr>
                            <td style="width:40%">Last Modified <br>Date</td>
                            <td>
                              <?php echo e($order->updated_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Order Amount</td>
                            <td>
                              <b>Rs.<?php echo e($order->orderAmount); ?>/-</b>
                            </td>
                        </tr>
                     </table>
                  </div>
                  <div class="col-md-7">
                    <table class="table table-bordered table-striped">
                      <h4 class="box-title"> Order Details </h4>
                        <tr>
                            <td style="width:30%">Expected Delivery</td>
                            <td>
                              <b><?php echo e(date('d-M-Y', strtotime($order->expectedDelivery))); ?></b>
                            </td>
                        </tr>

                        <tr>
                            <td style="width:30%">Vendor Amount</td>
                            <td>
                              <?php if($order->vendorAmount > 0): ?>
                                <b><?php echo e($order->vendorAmount); ?></b>
                              <?php else: ?>
                                N/A
                              <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Gross Profit Margin</td>
                            <td>
                              <?php if($order->vendorAmount > 0): ?>
                                <b><?php echo e($order->orderAmount - $order->vendorAmount); ?></b>
                              <?php else: ?>
                                N/A
                              <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Order Details</td>
                            <td>
                              <?php echo e($order->orderDetails); ?>

                            </td>
                        </tr>
                        <tr>
                            <td style="width:30%">Order Summary</td>
                            <td>
                              <?php echo e($order->orderSummary); ?>

                            </td>
                        </tr>
                     </table>
                  </div>
                </div>


               <table class="table table-bordered table-striped">
                 <h4 class="box-title"> Enquiry / Merchandise Details </h4>
                   <tr>
                       <td style="width:30%">Enquiry Details</td>
                       <td>
                         <a href="<?php echo e(URL::to('/')); ?>/enquiry/displayEnquiry/<?php echo e($enquiry->id); ?>" class="btn btn-success" target="_blank">View Enquiry</a>
                       </td>
                   </tr>
                   <tr>
                       <td style="width:30%">Approved Quotation</td>
                       <td>
                         <a href="<?php echo e(URL::to('/')); ?>/enquiry/quotation/<?php echo e($enquiry->id); ?>/<?php echo e($enquiryQuote[0]->quotation_code); ?>" class="btn btn-warning" target="_blank"><?php echo e($enquiryQuote[0]->quotation_code); ?></a>
                       </td>
                   </tr>
                </table>

               <table class="table table-bordered table-striped">
                 <h4 class="box-title"> Billing Details </h4>
                   <tr>
                       <td style="width:30%">Billing Address</td>
                       <td>
                         <?php echo e($order->billingAddress); ?>

                       </td>
                   </tr>
                </table>

                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> Shipment Details </h4>
                     <tr>
                         <td style="width:30%">Shipment Address</td>
                         <td>
                           <?php echo e($order->shipmentAddress); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Contact Person at Shipment</td>
                         <td>
                           <?php echo e($order->contactPersonAtShipment); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Contact Number at Shipment</td>
                         <td>
                           <?php echo e($order->contactNumberAtShipment); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Concerned Lead</td>
                         <td>
                           <?php echo e($order->concernedLead); ?>

                         </td>
                     </tr>
                  </table>

                  <?php if($order->orderStatus == 'ORDER DELIVERED' || $order->orderStatus == 'ORDER COMPLETED'): ?>
                  <table class="table table-bordered table-striped">
                    <h4 class="box-title"> Post-Order Delivery </h4>
                    <tr>
                        <td style="width:30%">Client Feedback</td>
                        <td>
                          <?php echo e($order->clientFeedback); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Comments</td>
                        <td>
                          <?php echo e($order->postOrderDeliveryComments); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">All Documents Verified with Client & Manager</td>
                        <td>
                          Yes
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Concerned Lead Signature</td>
                        <td>
                          <?php echo e($order->concernedLead); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Manager Signature</td>
                        <td>
                          <?php echo e($enquiry->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Admin Signature</td>
                        <td>
                          <?php echo e($order->concernedLead); ?>

                        </td>
                    </tr>
                  </table>
                <?php endif; ?>

            <?php if($order->orderStatus != 'ORDER COMPLETED'): ?>

              <table class="table table-bordered table-striped">
                <h4 class="box-title"> Status Updates </h4> <br>
                  <ul>
                  <?php $__currentLoopData = $orderStatusUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusUpdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <b> On <?php echo e($statusUpdate->creation_dttm); ?>, Mr. <?php echo e($statusUpdate->user); ?> Added : </b> <?php echo e($statusUpdate->comments); ?></li> <br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>

                  <a href="#addStatusUpdateModal" class="btn btn-primary ml-5" data-toggle="modal"> Add Update </a>

                  <div class="modal fade" id="addStatusUpdateModal" role="dialog">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/statusUpdate/save/<?php echo e($order->id); ?>" autocomplete="off">
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title"> Add Status Update To This Order </h4>
                          </div>
                          <div class="modal-body">
                            <b>Document Number : </b> <?php echo e($order->documentNumber); ?>

                            <br><br>
                            <b>Summary : </b> <?php echo e($order->orderDetails); ?>

                            <br><br>
                            <b>Merchandise : </b> <?php echo e($order->orderSummary); ?>

                            <br><br>
                            <b>Status : </b> <?php echo e($order->orderStatus); ?>

                            <br><br>
                            <b>Note : </b> <br><br>
                            <textarea rows="4" cols="50" class="form-control" type="text" id="orderStatusUpdate"
                            name="orderStatusUpdate" size="100" style="width:100%!important"
                            value="<?php echo e(old('sampleDetailsComments')); ?>" required></textarea>
                            <br>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>

               </table>
             <?php endif; ?>

                <table class="table table-bordered table-striped">
                  <h4 class="box-title"> Status Transitions </h4>
                  <tr>
                      <td style="width:30%"> Order Status</td>
                      <?php if($order->orderStatus == 'REQUEST FOR ORDER CONFIRMATION'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-success ml-2" type="submit">CONFIRM ORDER</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/cancel/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Cancel The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-danger ml-2" type="submit">CANCEL ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER ON HOLD'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-success ml-2" type="submit">CONFIRM ORDER</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/cancel/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Cancel The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-danger ml-2" type="submit">CANCEL ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER CANCELLED'): ?>
                        <td>
                          Order Has Been Cancelled.
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER CONFIRMED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/confirmProformaTechPack/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Proforma Invoice And Tech Pack?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-success ml-2" type="submit">CONFIRM PROFORMA INVOICE & TECH PACK</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PROFORMA INVOICE & TECH PACK GENERATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/reqAdvPayment/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue With Advance Payment Request?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-info ml-2" type="submit">REQUEST FOR ADVANCE PAYMENT</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'REQUEST FOR ADVANCE PAYMENT'): ?>
                        <td>
                          Requested Customer To Make An Advance Payment Towards The Order
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'REQUEST FOR PENDING PAYMENT'): ?>
                        <td>
                          Requested Customer To Make Pending Payment Towards The Order
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ADVANCE PAYMENT MADE. AWAITING ADMIN CONFIRMATION'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/reqAdvPayment/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Payment Made?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-info ml-2" type="submit">CONFIRM ADVANCE PAYMENT</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/reqAdvPayment/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue With Advance Payment Request?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-info ml-2" type="submit">RE-REQUEST FOR ADVANCE PAYMENT</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ADVANCE PAYMENT CONFIRMED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/paymentReceipt/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Payment Receipt?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">CONFIRM PAYMENT RECEIPT</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ADVANCE PAYMENT RECEIPT GENERATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Purchase Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM PURCHASE ORDER</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PURCHASE ORDER CREATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/production/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Order To Production?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM ORDER TO PRODUCTION</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER SENT TO PRODUCTION'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/production/samples/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue with Requesting Production Samples For The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">REQUEST FOR PRODUCTION SAMPLES</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PRODUCTION SAMPLES REQUESTED'): ?>
                        <td>
                          Production Samples Have Been Requested. Awating Production Team Response.
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PRODUCTION SAMPLES RECEIVED. AWAITING CUSTOMER CONFIRMATION'): ?>
                        <td>
                          Production Samples Have Been Received. Waiting for Customer Response.
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'REVISED PRODUCTION SAMPLES RECEIVED. AWAITING CUSTOMER CONFIRMATION'): ?>
                        <td>
                          Revised Production Samples Have Been Received. Waiting for Customer Response.
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'INCORPORATING CUSTOMER FEEDBACK. REQUEST FOR REVISED SAMPLES'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/production/revisedSamples/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue with Requesting Revised Production Samples For The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">REQUEST FOR REVISED PRODUCTION SAMPLES</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'REVISED PRODUCTION SAMPLES REQUESTED'): ?>
                        <td>
                          Revised Production Samples Requested.
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PRODUCTION SAMPLES CONFIRMED' || $order->orderStatus == 'REVISED PRODUCTION SAMPLES CONFIRMED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/production/bulkPrint/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Proceed With Bulk Printing For The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">PRODUCTION - PROCEED WITH BULK PRINTING</button>
                          </form>
                        </td>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/hold/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Hold The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-warning ml-2" type="submit">HOLD ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PRODUCTION BULK PRINTING CONFIRMED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/production/shipment/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue With Order Shipment?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">ORDER SHIPPED</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER SHIPPED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/deliveryChallan/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue With The Delivery Challans Generated?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM DELIVERY CHALLAN</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'DELIVERY CHALLAN GENERATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/orderDelivery/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Order Delivery Is Successful?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM ORDER DELIVERY</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER DELIVERED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/taxInvoice/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Order Tax Invoice?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM TAX INVOICE</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'TAX INVOICE GENERATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/pendingPayment/request/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Continue With Pending Payment Request With The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">REQUEST FOR PENDING PAYMENT</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'PENDING PAYMENT MADE. AWAITING ADMIN CONFIRMATION'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/fullPayment/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Are You Sure You've Received The Order Full Payment?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM FULL ORDER PAYMENT</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'FULL ORDER PAYMENT RECEIVED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/fullPaymentReceipt/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Confirm The Full Payment Receipt?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">CONFIRM FINAL PAYMENT RECEIPT</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'FINAL PAYMENT RECEIPT GENERATED'): ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/complete/confirm/<?php echo e($order->id); ?>" onsubmit="return confirm('Do You Really Want To Conmplete The Order?');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-primary ml-2" type="submit">COMPLETE ORDER</button>
                          </form>
                        </td>
                      <?php endif; ?>
                      <?php if($order->orderStatus == 'ORDER COMPLETED'): ?>
                        <td>
                          Order Completed.
                        </td>
                      <?php endif; ?>
                  </tr>
                </table>

                <table class="table table-bordered table-striped">
                  <?php if($order->orderStatus != 'ORDER COMPLETED'): ?>
                    <h4 class="box-title"> Action Items </h4>
                  <?php endif; ?>
                  <?php if($order->orderStatus == 'ADVANCE PAYMENT RECEIPT GENERATED'): ?>
                    <tr>
                        <td style="width:30%"> Purchase Order </td>
                        <td>
                          <?php if($order->purchaseOrderNumber != '///////////////'): ?>
                            <a href="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/update/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>/<?php echo e($order->purchaseOrderNumber); ?>" class="btn btn-warning ml-2" style="width: 30%;"> Update Purchase Order </a>
                          <?php else: ?>
                            <a href="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-info ml-2" style="width: 30%;"> Raise Purchase Order </a>
                          <?php endif; ?>
                      </td>
                    </tr>
                  <?php endif; ?>

                  <?php if($order->orderStatus == 'ORDER CONFIRMED'): ?>
                    <tr>
                        <td style="width:30%"> Tech Pack </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/admin/techPack/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-info ml-2" style="width: 30%;">Generate Tech Pack</a>
                        </td>
                    </tr>

                    <tr>
                        <td style="width:30%"> Proforma Invoice </td>
                        <td>
                          <a href="#proformaInvoiceModal" class="btn btn-info ml-2" style="width: 30%;" data-toggle="modal">Generate Proforma Invoice</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="proformaInvoiceModal" role="dialog" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/admin/proformaInvoice/save/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title"> Proforma Invoice Form </h4>
                            </div>
                            <div class="modal-body">
                              <b>Billing Address : </b> <?php echo e($order->billingAddress); ?>

                              <br><br>
                              <b>Shipping Address : </b> <?php echo e($order->shipmentAddress); ?>

                              <br><br>
                              <b>Client GST No : </b>
                              <input class="form-control" placeholder="Enter Client GST Number" type="text"
                              id="clientGstNum" name="clientGstNum" value="///////////////" required>
                              <br>
                              <b>Advance Payment (%) : </b>
                              <input class="form-control" placeholder="Enter Percentage Amount To Be Paid As Advance (Ranges from 0 - 50%)" type="number" id="advPayPer"
                              name="advPayPer" required>
                              <br>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  <?php endif; ?>

                  <?php if($order->orderStatus != 'ORDER COMPLETED'): ?>
                    <tr>
                        <td style="width:30%"> Customer Payment Details </td>
                        <td>
                          <?php if(($order->orderAmount - $order->customerPayments()->sum('total_payment_amount')) > 1): ?>
                            <a href="<?php echo e(URL::to('/')); ?>/order/admin/paymentReceipt/<?php echo e($order->id); ?>" class="btn btn-info ml-2" style="width: 30%;">Record Customer Payments</a>
                          <?php else: ?>
                            Full Customer Payment Received
                          <?php endif; ?>
                        </td>
                    </tr>

                    <?php if($order->vendorAmount != 0): ?>
                      <tr>
                          <td style="width:30%"> Vendor Payment Details </td>
                          <td>
                            <?php if(($order->vendorAmount - $order->vendorPayments()->sum('total_payment_amount')) > 1): ?>
                              <a href="<?php echo e(URL::to('/')); ?>/order/admin/vendor/paymentReceipt/<?php echo e($order->id); ?>" class="btn btn-info ml-2" style="width: 30%;">Record Vendor Payments</a>
                            <?php else: ?>
                              Full Vendor Payment Cleared
                            <?php endif; ?>
                          </td>
                      </tr>
                    <?php endif; ?>

                  <?php endif; ?>

                  <?php if($order->orderStatus == 'ORDER SHIPPED'): ?>
                    <tr>
                        <td style="width:30%"> Delivery Challan </td>
                        <td>
                          <a href="#deliveryChallanModal" class="btn btn-info ml-2" style="width: 30%;" data-toggle="modal">Generate Delivery Challan</a>
                        </td>
                    </tr>
                  <?php endif; ?>

                  <?php if($order->orderStatus == 'ORDER DELIVERED'): ?>
                    <tr>
                        <td style="width:30%"> Tax Invoice </td>
                        <td>
                          <a href="#taxInvoiceModal" class="btn btn-info ml-2" style="width: 30%;" data-toggle="modal">Generate Invoice</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="taxInvoiceModal" role="dialog" tabindex="-1" autocomplete="off">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/admin/invoice/save/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title"> Tax Invoice Form </h4>
                            </div>
                            <div class="modal-body">
                              <b>Billing Address : </b> <?php echo e($order->billingAddress); ?>

                              <br><br>
                              <b>Client GST No : </b>
                              <input class="form-control" placeholder="Enter Client GST Number" type="text"
                              id="clientGstNum" name="clientGstNum" value="<?php echo e($order->client_gst_number); ?>" required>
                              <br>
                              <b>Invoice Date : </b>
                              <input class="form-control" type="date" id="invoiceGenDate"
                              name="invoiceGenDate" required>
                              <br>
                              <b>Invoice Due Date : </b>
                              <input class="form-control" type="date" id="invoiceDueDate"
                              name="invoiceDueDate" required>
                              <br>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>

                  <?php endif; ?>
                </table>

                <table class="table table-bordered table-striped">
                  <?php if($order->proformaInvoiceNumber != '///////////////'): ?>
                    <h4 class="box-title"> Order Documents </h4>
                  <?php endif; ?>
                  <?php if($order->purchaseOrderNumber != '///////////////'): ?>
                    <tr>
                        <td style="width:30%"> Purchase Order </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" style="width: 30%;" target="_blank"> View Purchase Order </a>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if($order->proformaInvoiceNumber != '///////////////'): ?>
                    <tr>
                        <td style="width:30%"> Proforma Invoice </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/proformaInvoice/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" style="width: 30%;" target="_blank">View Proforma Invoice</a>
                        </td>
                    </tr>
                  <?php endif; ?>

                  <?php if($order->techPackNumber != '///////////////'): ?>
                    <tr>
                        <td style="width:30%"> Tech Pack </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/techPack/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" style="width: 30%;" target="_blank">View Tech Pack</a>
                        </td>
                    </tr>
                  <?php endif; ?>

                  <?php if(count($order->customerPayments()->get()) > 0): ?>
                    <tr>
                        <td> Customer Payments </td>
                        <?php
                          $customerPayments = $order->customerPayments()->select('cust_pay_code')->distinct()->get();
                        ?>
                        <td>
                        <?php $__currentLoopData = $customerPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/paymentReceipt/display/<?php echo e($order->id); ?>/<?php echo e($payment->cust_pay_code); ?>"
                              class="btn btn-success ml-2" target="_blank"><?php echo e($payment->cust_pay_code); ?></a>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if(count($order->vendorPayments()->get()) > 0): ?>
                    <tr>
                        <td style="width:30%;"> Vendor Payments </td>
                        <td>
                          <a style="width:30%;" href="<?php echo e(URL::to('/')); ?>/order/admin/vendor/paymentReceipt/display/<?php echo e($order->id); ?>" class="btn btn-success ml-2" target="_blank">View Vendor Payments</a>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if(count($order->deliveryChallans()->get()) > 0): ?>
                    <tr>
                        <td style="width:30%"> Delivery Challan </td>
                        <?php
                          $orderDeliveryChallans = $order->deliveryChallans()->select('delivery_challan_code')->distinct()->get();
                        ?>
                        <td>
                        <?php $__currentLoopData = $orderDeliveryChallans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryChallan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(URL::to('/')); ?>/order/deliveryChallan/display/<?php echo e($order->id); ?>/<?php echo e($deliveryChallan->delivery_challan_code); ?>" class="btn btn-success ml-2" target="_blank" style="width:30%;">DC - <?php echo e($deliveryChallan->delivery_challan_code); ?></a>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                  <?php endif; ?>
                  <?php if($order->invoiceDate != null): ?>
                    <tr>
                        <td style="width:30%"> Tax Invoice </td>
                        <td>
                          <a href="<?php echo e(URL::to('/')); ?>/order/invoice/display/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" class="btn btn-success ml-2" style="width: 30%;" target="_blank">View Tax Invoice</a>
                        </td>
                    </tr>
                  <?php endif; ?>
                </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>


  <!-- Delivery Challan Modal -->
  <div class="modal fade" id="deliveryChallanModal" role="dialog" tabindex="-1" autocomplete="off">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST" action = "<?php echo e(URL::to('/')); ?>/order/admin/deliveryChallan/save/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"> Delivery Challan Form </h4>
          </div>
          <div class="modal-body">
            <b>Billing Address : </b> <?php echo e($order->billingAddress); ?>

            <br><br>
            <b>Delivery Address : </b> <?php echo e($order->shipmentAddress); ?>

            <br><br>
            <b>Way Bill No : </b>
            <input class="form-control" placeholder="Enter Way Bill Number" type="text"
            id="wayBillNum" name="wayBillNum" required>
            <br>
            <b>Place Of Supply : </b>
            <input class="form-control" placeholder="Enter Place Of Supply" type="text"
            id="placeOfSupply" name="placeOfSupply" value="<?php echo e($enquiry->eventPlace); ?>" required>
            <br>
            <?php
              $orderDeliveryChallan = $order->deliveryChallans()->get();
            ?>
            <?php if(count($orderDeliveryChallan) > 0): ?>
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th class="text-center">Production Description</th>
                    <th class="text-center">Quantity Ordered</th>
                    <th class="text-center">Quantity Delivered</th>
                    <th class="text-center">Quantity Pending</th>
                  </tr>
                </thead>
                <tbody class="table">
                  <?php for($m=0; $m<count($orderDeliveryChallan); $m++): ?>
                    <tr>
                      <td>
                        <b><?php echo e($orderDeliveryChallan[$m]->product_description); ?></b>
                      </td>
                      <td>
                        <b><?php echo e($orderDeliveryChallan[$m]->total_quantity); ?></b>
                      </td>
                      <td>
                        <b><?php echo e($orderDeliveryChallan[$m]->delivered_quantity); ?></b>
                      </td>
                      <td>
                        <b><?php echo e($orderDeliveryChallan[$m]->balance_quantity); ?></b>
                      </td>
                    </tr>
                  <?php endfor; ?>

                  <?php for($n=0; $n<count($enquiryQuote); $n++): ?>
                    <tr>
                      <td>
                        <b><?php echo e($enquiryQuote[$n]->product_description); ?></b>
                        <input class="form-control" type="hidden" id="prodDescrDC" name="prodDescrDC[]" value="<?php echo e($enquiryQuote[$n]->product_description); ?>"/>
                      </td>
                      <td>
                        <b><?php echo e($enquiryQuote[$n]->quantity); ?></b></td>
                        <input class="form-control" type="hidden" id="orderedQtyDC" name="orderedQtyDC[]" value="<?php echo e($enquiryQuote[$n]->quantity); ?>"/>
                      <td>
                        <input class="form-control" type="number" id="deliveredQty" min="0" max="<?php echo e($orderDeliveryChallan[$n]->balance_quantity); ?>" name="deliveredQtyDC[]" required>
                      </td>
                    </tr>
                  <?php endfor; ?>
                </tbody>
              </table>
              <br>
            <?php else: ?>
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th class="text-center">Production Description</th>
                    <th class="text-center">Quantity Ordered</th>
                    <th class="text-center">Quantity Delivered</th>
                  </tr>
                </thead>
                <tbody class="table">
                  <?php $__currentLoopData = $enquiryQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quoteEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <b><?php echo e($quoteEntry->product_description); ?></b>
                        <input class="form-control" type="hidden" id="prodDescrDC" name="prodDescrDC[]" value="<?php echo e($quoteEntry->product_description); ?>"/>
                      </td>

                      <td>
                        <b><?php echo e($quoteEntry->quantity); ?></b></td>
                        <input class="form-control" type="hidden" id="orderedQtyDC" name="orderedQtyDC[]" value="<?php echo e($quoteEntry->quantity); ?>"/>
                      <td>
                        <input class="form-control" type="number" id="deliveredQty" name="deliveredQtyDC[]" min="0" max="<?php echo e($quoteEntry->quantity); ?>" required>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <br>
            <?php endif; ?>
            <b>Mode Of Transport : </b>
            <input class="form-control" placeholder="Enter The Mode Of Transport" type="text"
            id="modeOfTransport" name="modeOfTransport" required>
            <br>
            <b>Vehicle No : </b>
            <input class="form-control" placeholder="Enter The Vehicle Number" type="text"
            id="vehicleNum" name="vehicleNum" required>
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>