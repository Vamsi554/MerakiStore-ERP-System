<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Purchase Order | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Purchase Order Form </h3>
            </div>

            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>

               <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/purchaseOrder/save/<?php echo e($orderId); ?>" autocomplete="off">

                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                 <input type="hidden" name="concernedLeadPerson" id="concernedLeadPerson" value="<?php echo e(Auth::user()->name); ?>">
                 <input type="hidden" name="poCreDttm" id="poCreDttm" value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>">

                 <div class="row">
                   <div class="col-md-6">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Event Details </h4>
                           <tr class="<?php echo e($errors->has('eventName') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Event Name</td>
                               <td>
                                 <?php echo e($enquiry->eventName); ?>

                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('eventPlace') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Event Place</td>
                               <td>
                                 <?php echo e($enquiry->eventPlace); ?>

                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('organizationName') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Organization Name</td>
                               <td>
                                 <?php echo e($enquiry->organizationName); ?>

                               </td>
                           </tr>
                      </table>
                   </div>

                   <div class="col-md-6">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Contact Details </h4>
                           <tr class="<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Name</td>
                               <td>
                                 <?php echo e($enquiry->name); ?>

                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Phone</td>
                               <td>
                                 <?php echo e($enquiry->phone); ?>

                               </td>
                           </tr>

                           <tr class="<?php echo e($errors->has('designation') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Designation</td>
                               <td>
                                 <?php echo e($enquiry->designation); ?>

                               </td>
                           </tr>
                      </table>
                   </div>

                   <div class="col-md-12">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title">Vendor Details</h4>

                         <tr class="<?php echo e($errors->has('vendorCd') ? 'has-error' : ''); ?>">
                             <td style="width:30%">Vendor</td>
                             <td>
                               <select class="form-control" id="vendorCd" name="vendorCd" required>
                                <?php $__currentLoopData = $vendorDtls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorCd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
                                   <option><?php echo e($vendorCd->vendor_code); ?></option>
                                }
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>
                               <span class="text-danger"><?php echo e($errors->first('vendorCd')); ?></span>
                             </td>
                         </tr>
                      </table>
                   </div>
                 </div>

                  <table class="table table-bordered table-striped">
                    <h4 class="box-title"> Requirement Details </h4>
                      <input type="hidden" id="reqCount" name="reqCount">
                      <table class="table table-bordered table-hover" id="tab_logic">
                        <thead>
                          <tr>
                            <th class="text-center">Product Category</th>
                            <th class="text-center">Product Description</th>
                            <th class="text-center">Customization Details</th>
                            <th class="text-center">HSN</th>
                            <th class="text-center">Cost Per Unit</th>
                            <th class="text-center">GST Tax (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $i = 0; ?>
                          <?php $__currentLoopData = $enquiryRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiryReq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id='addr<?php echo $i; ?>'>
                              <td style="width:15%;">
                                <?php echo e($enquiryReq->product_category); ?>

                                <input type="hidden" id='prodCat<?php echo $i; ?>' name='prodCat[]' value="<?php echo e($enquiryReq->product_category); ?>">
                              </td>
                              <td style="width:15%;">
                                <?php echo e($enquiryReq->product_description); ?>

                                <input type="hidden" id='prodDescr<?php echo $i; ?>' name='prodDescr[]' value="<?php echo e($enquiryReq->product_description); ?>">
                              </td>
                              <td>
                                <b>Product Features</b>
                                <ul>
                                  <li>Product Style : <?php if($enquiryReq->product_style == '0' || $enquiryReq->product_style == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->product_style); ?> <?php endif; ?></li>
                                  <li>Material : <?php if($enquiryReq->material == '0' || $enquiryReq->material == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->material); ?> <?php endif; ?></li>
                                  <li>Quantity : <?php if($enquiryReq->quantity == '0' || $enquiryReq->quantity == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quantity); ?> <?php endif; ?></li>
                                    <input type="hidden" id='quantity<?php echo $i; ?>' name='quantity[]' value="<?php echo e($enquiryReq->quantity); ?>">
                                  <li>Quality : <?php if($enquiryReq->quality == '0' || $enquiryReq->quality == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quality); ?> <?php endif; ?></li>
                                  <li>Fabric: <?php if($enquiryReq->fabric == '0' || $enquiryReq->fabric == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->fabric); ?> <?php endif; ?></li>
                                  <?php if($enquiryReq->additional_features != '0' && $enquiryReq->additional_features != null && $enquiryReq->additional_features != 'N/A'): ?>
                                    <li><?php echo e($enquiryReq->additional_features); ?><li>
                                  <?php endif; ?>
                                </ul>

                                <b>Product Customizations</b>
                                <ul>
                                  <li>Colour: <?php if($enquiryReq->colour == '0' || $enquiryReq->colour == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->colour); ?> <?php endif; ?></li>
                                  <li>Print Methods: <?php if($enquiryReq->print_methods == '0' || $enquiryReq->print_methods == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_methods); ?> <?php endif; ?></li>
                                  <li>Print Placements: <?php if($enquiryReq->print_placements == '0' || $enquiryReq->print_placements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_placements); ?> <?php endif; ?></li>
                                  <li>Print Area: <?php if($enquiryReq->print_area == '0' || $enquiryReq->print_area == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_area); ?> <?php endif; ?></li>
                                  <li>Measurements: <?php if($enquiryReq->measurements == '0' || $enquiryReq->measurements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->measurements); ?> <?php endif; ?></li>
                                  <?php if($enquiryReq->additional_customizations != '0' && $enquiryReq->additional_customizations != null && $enquiryReq->additional_customizations != 'N/A'): ?>
                                    <li><?php echo e($enquiryReq->additional_customizations); ?><li>
                                  <?php endif; ?>
                                </ul>
                              </td>

                              <td style="width: 100px;"><input class="form-control" type="text" id="hsn<?php echo e($i); ?>" name="hsnCode[]" value="<?php echo e($hsnCodeArr[$i]); ?>" required></td>
                              <td style="width: 100px;"><input class="form-control" type="number" min="0" step="any" id="cpu<?php echo e($i); ?>" name="costPerUnit[]" value="0" required></td>
                              <td style="width: 100px;"><input class="form-control" type="number" min="0" id="gst<?php echo e($i); ?>" name="gstTax[]" value="<?php echo e($gstTaxArr[$i]); ?>" required></td>
                            </tr>
                            <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                  </table>

                  <button class="btn btn-primary" id="quoteBreakUp">View Breakup</button>

                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Cost Per Unit</th>
                        <th>GST Tax</th>
                        <th>Amount Per Unit</th>
                        <th>Total Amount</th>
                      </tr>
                    </thead>
                    <h4 class="box-title"> P.O Breakup </h4>
                    <?php $j = 0; ?>
                    <?php $__currentLoopData = $enquiryRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiryReq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($enquiryReq->product_description); ?></td>
                        <td><p id="quoteQty<?php echo e($j); ?>"><?php echo e($enquiryReq->quantity); ?></p></td>
                        <td><p id="quoteCpu<?php echo e($j); ?>">0</p></td>
                        <td><p id="quoteGst<?php echo e($j); ?>">0</p></td>
                        <td><p id="quoteApu<?php echo e($j); ?>">0</p></td>
                        <td><p id="quoteTotAmt<?php echo e($j); ?>">0</p></td>
                      </tr>
                      <?php $j++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr></tr><tr></tr>
                    <tr><td></td><td></td><td></td><td></td><td><b>Final Amount</b></td><td><b><p id="finalQuotationAmountGen">0</p></b></td></tr>
                   </table>

                   <table class="table table-bordered table-striped">
                     <h4 class="box-title"> Terms & Conditions </h4>
                       <input type="hidden" id="reqCountTc" name="reqCountTc">
                       <table class="table table-bordered table-hover" id="tab_logic_terms">
                         <thead>
                           <tr>
                             <th class="text-center">Confirmation</th>
                             <th class="text-center">T&C Description</th>
                           </tr>
                         </thead>
                         <tbody>
                           <tr id="terms0">
                             <td style="width: 20%;">
                               <select class="form-control" name="status[]"
                               value="<?php echo e(old('status')); ?>" required>
                                <option selected="selected">Enable</option>
                                <option>Disable</option>
                               </select>
                             </td>
                             <td>
                               <input class="form-control" type="text" name="termsConditionsText[]" required>
                             </td>
                           </tr>
                           <tr id="terms1">
                           </tr>
                         </tbody>
                       </table>

                       <p id="addRow" class="btn btn-primary" style="float:left;">Add Row</p>
                       <p id="deleteRow" class="btn btn-danger" style="float:right;">Delete Row</p>
                       <br><br>
                   </table>


                   <table class="table table-bordered table-striped">
                     <h4 class="box-title"> Special Instructions/Notes </h4>
                     <tr class="<?php echo e($errors->has('notes') ? 'has-error' : ''); ?>">
                         <td style="width:30%">Notes</td>
                         <td>
                           <input class="form-control" type="text" id="notes"
                           name="notes" size="27" style="width:100%!important" value="<?php echo e(old('notes')); ?>" required>
                           <span class="text-danger"><?php echo e($errors->first('notes')); ?></span>
                         </td>
                     </tr>
                   </table>

                   <button class="btn btn-primary" type="submit">Generate Purchase Order</button>
              </form>
              <br/>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

  <script type="text/javascript">

      $(document).ready(function() {

          var i = $('#tab_logic tr').length - 1;

          $('#reqCount').val(i);

          $("#quoteBreakUp").click(function(event) {

              event.preventDefault();
              var $totalProdCnt = $('#tab_logic tr').length - 1;
              var $finalQuotePrice = 0;

              for(var $k=0; $k<$totalProdCnt; $k++) {

                  var $costPerUnitIter = $('#cpu' + $k).val();
                  var $gstIter = $('#gst' + $k).val();
                  var $qtyIter = $('#quoteQty' + $k).text();
                  $("#quoteCpu" + $k).text($costPerUnitIter);
                  var $gstTaxAmt = ($costPerUnitIter * $gstIter)/100.0;
                  $("#quoteGst" + $k).text($gstTaxAmt);
                  var $finalAmtPerUnit = parseInt($costPerUnitIter) + parseInt($gstTaxAmt);
                  $("#quoteApu" + $k).text($finalAmtPerUnit);
                  var $totalAmountIter = parseInt($qtyIter) * $finalAmtPerUnit;
                  $finalQuotePrice += $totalAmountIter;
                  $("#quoteTotAmt" + $k).text($totalAmountIter);
              }
              $("#finalQuotationAmountGen").text($finalQuotePrice);
          });

          // Terms & Conditions

          var v = $('#tab_logic_terms tr').length - 2;

          $('#reqCountTc').val(v);

          $('#addRow').click(function() {

              $('#terms' + v).html(""
              + "<td style='width: 20%;'><select class='form-control' name='status[]' value='<?php echo e(old('status')); ?>' required><option selected='selected'>Enable</option><option>Disable</option></select></td>"
              + "<td><input class='form-control' type='text' name='termsConditionsText[]' required></td>");

              v++;

              $('#tab_logic_terms').append('<tr id="terms'+(v)+'"></tr>');

              $('#reqCountTc').val(v);

          });

          $('#deleteRow').click(function() {

              if(v>1){
                $("#terms"+(v-1)).html('');
                $('#reqCountTc').val(v-1);
                v--;
              }
          });
      });
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>