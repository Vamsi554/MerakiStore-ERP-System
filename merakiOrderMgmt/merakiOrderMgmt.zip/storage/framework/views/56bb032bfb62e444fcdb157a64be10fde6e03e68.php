<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Task Management
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tasks | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Subject</th>
                  <th>Issued By</th>
                  <th>Issued To</th>
                  <th>Status</th>
                  <th>Note</th>
                  <th>Update</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $sNo = 1
                ?>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($sNo++); ?></td>
                    <td><a href="<?php echo e(URL::to('/')); ?>/meraki/tasks/displayTask/<?php echo e($task->id); ?>"><?php echo e($task->subject); ?></a></td>
                    <td><?php echo e($task->issuer); ?></td>
                    <td><?php echo e($task->issued_to); ?></td>
                    <?php if($task->status == 'Open'): ?>
                      <td><span class="label label-danger">Open</span></td>
                    <?php endif; ?>

                    <?php if($task->status == 'Pending Approval'): ?>
                      <td><span class="label label-warning">Pending Approval</span></td>
                    <?php endif; ?>

                    <?php if($task->status == 'Completed'): ?>
                      <td><span class="label label-success">Completed</span></td>
                    <?php endif; ?>
                    <td>
                      <?php if($task->status != 'Open' && $task->status != 'Pending Approval'): ?>
                        N/A
                      <?php else: ?>
                          <a href="#addTaskNoteModal" class="btn btn-info ml-2" data-toggle="modal" style="padding-right:10px;">Note</a>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($task->issuer != \Auth::user()->email): ?>
                         N/A
                      <?php else: ?>
                        <?php if($task->status != 'Completed'): ?>
                          <a href="<?php echo e(URL::to('/')); ?>/meraki/tasks/updateTask/<?php echo e($task->id); ?>" class="btn btn-warning ml-2" style="padding-right:10px;">Update</a>
                        <?php else: ?>
                          N/A
                        <?php endif; ?>
                      <?php endif; ?>
                    </td>
                    <?php if(\Auth::user()->email == $task->issuer): ?>
                      <?php if($task->status != 'Open' && $task->status != 'Pending Approval'): ?>
                        <td> N/A </td>
                      <?php else: ?>
                        <td>
                          <form method="POST" action="<?php echo e(URL::to('/')); ?>/meraki/tasks/completeTask/<?php echo e($task->id); ?>" onsubmit="return confirm('Are You Sure You Want To Complete The Task? Action Can\'t Be Reverted!');">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" class="btn btn-success ml-2" value="Complete">
                          </form>
                        </td>
                      <?php endif; ?>
                    <?php else: ?>
                      <td> N/A </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <a href="<?php echo e(URL::to('/')); ?>/meraki/tasks/addTask" class="btn btn-primary ml-2">Assign Task</a>

      <div class="modal fade" id="addTaskNoteModal" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <form method="POST" action = "<?php echo e(URL::to('/')); ?>/meraki/tasks/addNote/save/<?php echo e($task->id); ?>" autocomplete="off">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Add Note </h4>
              </div>
              <div class="modal-body">
                <b>Issued By : </b> <?php echo e($task->issuer); ?>

                <br><br>
                <b>Issued To : </b> <?php echo e($task->issued_to); ?>

                <br><br>
                <b>Task : </b> <?php echo e($task->subject); ?>

                <br><br>
                <b>Details : </b> <?php echo e($task->description); ?>

                <br><br>
                <b>Note : </b> <br><br>
                <textarea rows="4" cols="50" class="form-control" type="text" id="taskNote"
                name="taskNote" size="27" style="width:100%!important"
                value="<?php echo e(old('taskNote')); ?>" required></textarea>
                <br>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary" id="btnSave">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </form>
          </div>
        </div>
      </div>


    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>