<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Tech Pack | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Tech Pack Order Form </h3>
            </div>

            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>

               <form method="POST" action="<?php echo e(URL::to('/')); ?>/order/admin/techpack/save/<?php echo e($order->id); ?>/<?php echo e($order->enquiry_id); ?>" autocomplete="off">

                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                 <input type="hidden" name="techPackCreDttm" id="techPackCreDttm" value="<?php echo e(Carbon\Carbon::now()->toDateString()); ?>">

                 <div class="row">
                   <div class="col-md-6">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Event Details </h4>
                           <tr class="<?php echo e($errors->has('eventName') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Event Name</td>
                               <td>
                                 <?php echo e($enquiry->eventName); ?>

                               </td>
                           </tr>
                           <tr class="<?php echo e($errors->has('eventPlace') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Event Place</td>
                               <td>
                                 <?php echo e($enquiry->eventPlace); ?>

                               </td>
                           </tr>
                           <tr class="<?php echo e($errors->has('organizationName') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Organization Name</td>
                               <td>
                                 <?php echo e($enquiry->organizationName); ?>

                               </td>
                           </tr>
                      </table>
                   </div>

                   <div class="col-md-6">
                     <table class="table table-bordered table-striped">
                       <h4 class="box-title"> Contact Details </h4>
                           <tr class="<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Name</td>
                               <td>
                                 <?php echo e($enquiry->name); ?>

                               </td>
                           </tr>
                           <tr class="<?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Phone</td>
                               <td>
                                 <?php echo e($enquiry->phone); ?>

                               </td>
                           </tr>
                           <tr class="<?php echo e($errors->has('designation') ? 'has-error' : ''); ?>">
                               <td style="width:30%">Designation</td>
                               <td>
                                 <?php echo e($enquiry->designation); ?>

                               </td>
                           </tr>
                      </table>
                   </div>
                 </div>

                   <table class="table table-bordered table-striped">
                    <h4 class="box-title"> Requirement Details </h4>

                      <table class="table table-bordered table-hover" id="tab_logic">
                        <thead>
                          <tr>
                            <th class="text-center">Product Description</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-center">Estimated Delivery</th>
                            <th class="text-center">Breakup</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php for($i=0; $i<count($prodCatArr); $i++): ?>
                            <tr id='addr<?php echo $i; ?>'>
                              <td style="width:25%;">
                                <?php echo e($prodCatArr[$i]); ?>

                                <input type="hidden" id='prodDescr<?php echo $i; ?>' name='prodDescr[]' value="<?php echo e($prodCatArr[$i]); ?>">
                              </td>
                              <td style="width:15%;">
                                <?php echo e($prodQtyArr[$i]); ?>

                                <input type="hidden" id='prodQty<?php echo $i; ?>' name='prodQty[]' value="<?php echo e($prodQtyArr[$i]); ?>">
                              </td>
                              <td style="width:25%;">
                                <input class="form-control" type="date" id='estDelivery<?php echo $i; ?>' name='estDelivery[]'>
                              </td>
                              <td>
                                <input class="form-control" type="text" id='breakUp<?php echo $i; ?>' name='breakUp[]'>
                              </td>
                            </tr>
                          <?php endfor; ?>
                        </tbody>
                      </table>
                  </table>

                   <button class="btn btn-primary" type="submit">Generate Tech Pack</button>
              </form>
              <br/>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>