<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Enquiry | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> Enquiry - <span style="color:#Ffce37;"><b><?php echo e($enquiry->documentNumber); ?>, <?php echo e($enquiry->enquiryStatus); ?></b></span></h3>
            </div>

        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <table class="table table-bordered table-striped">
                <h4 class="box-title"> Basic Details </h4>
                    <tr>
                        <td style="width:30%">Lead Person</td>
                        <td>
                          <?php echo e($enquiry->concernedLeadPerson); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Creation Date</td>
                        <td>
                          <?php echo e($enquiry->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Last Modified Date</td>
                        <td>
                          <?php echo e($enquiry->updated_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Lead Source</td>
                        <td>
                          <?php echo e($enquiry->leadSource); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Document Number</td>
                        <td>
                          <b><?php echo e($enquiry->documentNumber); ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Organization Name</td>
                        <td>
                          <b><?php echo e($enquiry->organizationName); ?></b>
                        </td>
                    </tr>
               </table>
            </div>
            <div class="col-md-6">
              <table class="table table-bordered table-striped">
                <h4 class="box-title"> Event & Contact Details </h4>
                    <tr>
                        <td style="width:30%">Event Name</td>
                        <td>
                          <b><?php echo e($enquiry->eventName); ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Event Place</td>
                        <td>
                          <?php echo e($enquiry->eventPlace); ?>

                        </td>
                    </tr>

                    <tr>
                        <td style="width:30%">Event Date</td>
                        <td>
                          <b><?php echo e(date('d-M-Y', strtotime($enquiry->eventDate))); ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Contact</td>
                        <td>
                          <?php echo e($enquiry->name); ?>, <?php echo e($enquiry->designation); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Phone</td>
                        <td>
                          <?php echo e($enquiry->phone); ?>

                          <?php if($enquiry->alternatePhone != null): ?>
                            , <?php echo e($enquiry->alternatePhone); ?>

                          <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:30%">Email Address</td>
                        <td>
                          <?php echo e($enquiry->email); ?>

                        </td>
                    </tr>
               </table>
            </div>
          </div>

              <table class="table table-bordered table-striped">
                <h4 class="box-title"> Requirement Details </h4>
                  <input type="hidden" id="reqCount" name="reqCount">
                  <table class="table table-bordered table-hover" id="tab_logic">
                    <thead>
                      <tr>
                        <th class="text-center">Product Details</th>
                        <th class="text-center">Art Work Design</th>
                        <th class="text-center">Customization Details</th>
                        <th class="text-center">Additional Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i = 0; ?>
                      <?php $__currentLoopData = $enquiryRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiryReq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id='addr<?php echo $i; ?>'>
                          <td style="width:22%;">
                            <b>Category</b> : <?php echo e($enquiryReq->product_category); ?> <br><br>

                            <b>Description</b> : <?php echo e($enquiryReq->product_description); ?> <br><br>

                            <?php if($enquiryReq->status == 'Approved'): ?>
                              <span class="label label-success">Approved</span>
                            <?php elseif($enquiryReq->status == 'Hold'): ?>
                              <span class="label label-warning">Hold</span>
                            <?php else: ?>
                              <span class="label label-danger">Cancel</span>
                            <?php endif; ?>
                          </td>
                          <td style="width:15%;">
                            <?php echo e($enquiryReq->art_work_notes); ?>

                          </td>
                          <td style="width: 32%;">
                            <b>Product Features</b>
                            <ul>
                              <li>Product Style : <?php if($enquiryReq->product_style == '0' || $enquiryReq->product_style == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->product_style); ?> <?php endif; ?></li>
                              <li>Material : <?php if($enquiryReq->material == '0' || $enquiryReq->material == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->material); ?> <?php endif; ?></li>
                              <li>Quantity : <?php if($enquiryReq->quantity == '0' || $enquiryReq->quantity == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quantity); ?> <?php endif; ?></li>
                              <li>Quality : <?php if($enquiryReq->quality == '0' || $enquiryReq->quality == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->quality); ?> <?php endif; ?></li>
                              <li>Fabric: <?php if($enquiryReq->fabric == '0' || $enquiryReq->fabric == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->fabric); ?> <?php endif; ?></li>
                              <?php if($enquiryReq->additional_features != '0' && $enquiryReq->additional_features != null && $enquiryReq->additional_features != 'N/A'): ?>
                                <li><?php echo e($enquiryReq->additional_features); ?><li>
                              <?php endif; ?>
                            </ul>

                            <b>Product Customizations</b>
                            <ul>
                              <li>Colour: <?php if($enquiryReq->colour == '0' || $enquiryReq->colour == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->colour); ?> <?php endif; ?></li>
                              <li>Print Methods: <?php if($enquiryReq->print_methods == '0' || $enquiryReq->print_methods == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_methods); ?> <?php endif; ?></li>
                              <li>Print Placements: <?php if($enquiryReq->print_placements == '0' || $enquiryReq->print_placements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_placements); ?> <?php endif; ?></li>
                              <li>Print Area: <?php if($enquiryReq->print_area == '0' || $enquiryReq->print_area == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->print_area); ?> <?php endif; ?></li>
                              <li>Measurements: <?php if($enquiryReq->measurements == '0' || $enquiryReq->measurements == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->measurements); ?> <?php endif; ?></li>
                              <?php if($enquiryReq->additional_customizations != '0' && $enquiryReq->additional_customizations != null && $enquiryReq->additional_customizations != 'N/A'): ?>
                                <li><?php echo e($enquiryReq->additional_customizations); ?><li>
                              <?php endif; ?>
                            </ul>
                          </td>
                          <td>
                            <b>Finishing</b> : <?php if($enquiryReq->finishing == '0' || $enquiryReq->finishing == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->finishing); ?> <?php endif; ?> <br><br>
                            <b>Packaging</b> : <?php if($enquiryReq->packaging == '0' || $enquiryReq->packaging == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->packaging); ?> <?php endif; ?> <br><br>
                            <b>Inclusive</b> : <?php if($enquiryReq->inclusive == '0' || $enquiryReq->inclusive == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->inclusive); ?> <?php endif; ?> <br><br>
                            <b>Exclusive</b> : <?php if($enquiryReq->exclusive == '0' || $enquiryReq->exclusive == null): ?> N/A <?php else: ?> <?php echo e($enquiryReq->exclusive); ?> <?php endif; ?> <br><br>
                          </td>
                        </tr>
                        <?php $i++; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
              </table>

              <table class="table table-bordered table-striped">
                <h4 class="box-title"> Enquiry Status </h4>
                    <tr>
                        <td style="width:30%">Enquiry Status</td>
                        <td>
                          <?php if($enquiry->enquiryStatus == 'APPROVED'): ?>
                            <span class="label label-success">APPROVED</span>
                          <?php else: ?>
                            <span class="label label-warning"><?php echo e($enquiry->enquiryStatus); ?></span>
                          <?php endif; ?>
                        </td>
                    </tr>
               </table>

               <?php if(count($enquiryQuoteLinkage) > 0 && ($enquiry->enquiryStatus == 'APPROVED' || $enquiry->enquiryStatus == 'REQUEST FOR QUOTATION' || $enquiry->enquiryStatus == 'REQUEST FOR REVISED QUOTATION')): ?>
                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> View Quotations </h4>
                   <?php $__currentLoopData = $enquiryQuoteLinkage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <td style="width:30%">Effective Date : <?php echo e($quote->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?></td>
                         <td>
                           <a href="<?php echo e(URL::to('/')); ?>/enquiry/quotation/<?php echo e($enquiry->id); ?>/<?php echo e($quote->quotation_code); ?>" class="btn btn-success" target="_blank">View Quotation</a>
                         </td>
                     </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
               <?php endif; ?>

               <?php if(count($enquiryQuoteLinkage) > 0 && ($enquiry->enquiryStatus != 'APPROVED' && $enquiry->enquiryStatus != 'REQUEST FOR QUOTATION' && $enquiry->enquiryStatus != 'REQUEST FOR REVISED QUOTATION')): ?>

                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> View Quotations </h4>

                   <?php $__currentLoopData = $enquiryQuoteLinkage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <td style="width:30%">Effective Date : <?php echo e($quote->created_at->setTimezone("Asia/Kolkata")->format("d-M-Y h:i A")); ?></td>
                         <td>
                           <a href="<?php echo e(URL::to('/')); ?>/enquiry/quotation/<?php echo e($enquiry->id); ?>/<?php echo e($quote->quotation_code); ?>" class="btn btn-success" target="_blank">View Quotation</a>
                         </td>
                         <td>
                         <?php if($quote->quotation_status == 'APPROVED'): ?>
                           <a href="javascript:void(0);" class="btn btn-default disabled">Proceed With Order Creation</a>
                         <?php else: ?>
                           <a href="<?php echo e(URL::to('/')); ?>/order/createOrder/<?php echo e($enquiry->id); ?>/<?php echo e($quote->quotation_code); ?>" class="btn btn-warning" target="_blank">Proceed With Order Creation</a>
                         <?php endif; ?>
                         </td>
                     </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </table>
               <?php endif; ?>

               <?php if($enquiry->quotationResponse != null OR $enquiry->quotationResponse != ''): ?>
                 <table class="table table-bordered table-striped">
                   <h4 class="box-title"> Quotation Response </h4>
                     <tr>
                         <td style="width:30%">Response</td>
                         <td>
                           <?php echo e($enquiry->quotationResponse); ?>

                         </td>
                     </tr>
                 </table>
               <?php endif; ?>

               <table class="table table-bordered table-striped">
                 <h4 class="box-title"> Sample Details </h4>
                     <tr>
                         <td style="width:30%">Sample Package Sent</td>
                         <td>
                            <?php echo e($enquiry->sampleDetailsSent); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Sample Package Comments</td>
                         <td>
                           <?php echo e($enquiry->sampleDetailsComments); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Customer Received Sample Package</td>
                         <td>
                           <?php echo e($enquiry->sampleReceivedByCustomer); ?>

                         </td>
                     </tr>
                     <tr>
                         <td style="width:30%">Customer Review & Feedback</td>
                         <td>
                           <?php echo e($enquiry->samplesCustomerFeedback); ?>

                         </td>
                     </tr>
                </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>