<?php $__env->startSection('loadCustomJs'); ?>
  <style type="text/css">
      .column {
        float: left;
        width: 50%;
        padding: 10px;
      }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Quotation #<?php echo e($quoteCd); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
            class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
            <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
            <address>
              <p style="font-size: 15px;">
              D.No:101, Near SR Club, Sri Nagar Colony<br>
              Hyderabad, Telangana<br>
              Tel: 040-48554470, 9000909109<br><br>
              Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
            </p>
          </span>
          </h2>
        </div>
      </div>

      <div class="row invoice-info">
        <div class="col-xs-12">
          <h4 class="text-center"><strong> QUOTATION LETTER </strong></h4>
          <p style="float:right"><strong>Date:</strong> <?php echo e(date("d-M-Y", strtotime($enquiryQuote[0]->quoteCreDttm))); ?></p>
          <strong>To,</strong><br>
          <?php echo e($enquiry->name); ?>,<br>
          <?php echo e($enquiry->organizationName); ?>,<br>
          <?php echo e($enquiry->eventName); ?>,<br>
          <?php echo e($enquiry->eventPlace); ?>.<br>
          <br>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <strong>Kind Attn: </strong> Mr/Mrs. <?php echo e($enquiry->name); ?>, <?php echo e($enquiry->designation); ?> <br>
          Mob. No. <?php echo e($enquiry->phone); ?> <br>
          <br>
          <strong>Sub: <?php echo e($enquiry->eventName); ?> Merchandise Kit Quotation Details.</strong><br>
          <br>
          <p> Dear Sir/Madam, <br><br>

              Merakii is a one stop destination for all your Merchandise needs be it for college or corporate events.
              With the objective of providing our customers with a range of customised products, our Team at Merakii work
              round the clock striving for perfection and punctuality, while also ensuring affordable pricing!
              <br><br>
              With reference to the requirement mentioned from your side, please go through the attached quotation as requested and our sales executive will get in touch with you in
              the next 48 hrs to guide you through the remaining process.
          </p>
        </div>
      </div>

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr>
              <th>SNo</th>
              <th>Product</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Taxable Amount</th>
              <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                <th>CGST</th>
                <th>SGST</th>
              <?php else: ?>
                <th>IGST</th>
              <?php endif; ?>
              <th>Total Amount</th>
            </tr>
            </thead>
            <tbody>
              <?php
                $index = 1
              ?>
              <?php $__currentLoopData = $enquiryQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quoteEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index++); ?></td>
                  <td><?php echo e($quoteEntry->product_description); ?></td>
                  <td><?php echo e($quoteEntry->quantity); ?> Units</td>
                  <td>Rs.<?php echo e($quoteEntry->cost_per_unit); ?>/-</td>
                  <?php
                    $totAmt = $quoteEntry->cost_per_unit * $quoteEntry->quantity;
                    $taxPer = $quoteEntry->gst_tax;
                    $indvTaxPer = $quoteEntry->gst_tax/2.0;
                    $cgst = $totAmt * $indvTaxPer/100.0;
                    $sgst = $totAmt * $indvTaxPer/100.0;
                    $igst = $cgst + $sgst;
                    $finalAmount = $totAmt + $cgst + $sgst;
                  ?>
                  <td>Rs.<?php echo e($totAmt); ?>/-</td>
                  <?php if($enquiryQuoteLinkage[0]->tax_code == 'CGST/SGST'): ?>
                    <td>Rs.<?php echo e($cgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
                    <td>Rs.<?php echo e($sgst); ?>/- <sub><b>(<?php echo e($indvTaxPer); ?>%)</b></sub></td>
                  <?php else: ?>
                    <td>Rs.<?php echo e($igst); ?>/- <sub><b>(<?php echo e($taxPer); ?>%)</b></sub></td>
                  <?php endif; ?>
                  <td>Rs.<?php echo e($finalAmount); ?>/-</td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      <div style="page-break-before: always; width: 100%;" class="page-header headerContent">
        <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
        class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
        <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
          <address>
            <p style="font-size: 15px;">
            D.No:101, Near SR Club, Sri Nagar Colony<br>
            Hyderabad, Telangana<br>
            Tel: 040-48554470, 9000909109<br><br>
            Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
          </p>
      </div>

      <h4><?php echo e($enquiryQuote[0]->product_description); ?> Features</h4>
      <div class="row">
        <div class="column">
          <h4 class="box-title">Product Features</h4>
          <ul>
            <li>Product Style: <?php echo e($enquiryRequirements[0]->product_style); ?></li>
            <li>Material: <?php echo e($enquiryRequirements[0]->material); ?></li>
            <li>Quality: <?php echo e($enquiryRequirements[0]->quality); ?></li>
            <li>Fabric: <?php echo e($enquiryRequirements[0]->fabric); ?></li>
            <li>Colour: <?php echo e($enquiryRequirements[0]->colour); ?></li>
            <?php if($enquiryRequirements[0]->additional_features != 'N/A'): ?>
              <li>Additional Features: <?php echo e($enquiryRequirements[0]->additional_features); ?></li>
            <?php endif; ?>
          </ul>
        </div>
        <div class="column">
          <h4 class="box-title">Product Customizations</h4>
          <ul>
            <li>Print Methods: <?php echo e($enquiryRequirements[0]->product_style); ?></li>
            <li>Print Placements: <?php echo e($enquiryRequirements[0]->material); ?></li>
            <li>Print Area: <?php echo e($enquiryRequirements[0]->quality); ?></li>
            <li>Measurements: <?php echo e($enquiryRequirements[0]->fabric); ?></li>
            <?php if($enquiryRequirements[0]->additional_customizations != 'N/A'): ?>
              <li>Additional Customization: <?php echo e($enquiryRequirements[0]->additional_customizations); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <h4>Conditions</h4>
      <ul>
        <li>Finishing: <?php echo e($enquiryRequirements[0]->finishing); ?></li>
        <li>Packaging: <?php echo e($enquiryRequirements[0]->packaging); ?></li>
        <li>Inclusive: <?php echo e($enquiryRequirements[0]->inclusive); ?></li>
        <li>Exclusive: <?php echo e($enquiryRequirements[0]->exclusive); ?></li>
      </ul>
      <br>

      <h4><?php echo e($enquiryQuote[1]->product_description); ?> Features</h4>
      <div class="row">
        <div class="column">
          <h4 class="box-title">Product Features</h4>
          <ul>
            <li>Product Style: <?php echo e($enquiryRequirements[1]->product_style); ?></li>
            <li>Material: <?php echo e($enquiryRequirements[1]->material); ?></li>
            <li>Quality: <?php echo e($enquiryRequirements[1]->quality); ?></li>
            <li>Fabric: <?php echo e($enquiryRequirements[1]->fabric); ?></li>
            <li>Colour: <?php echo e($enquiryRequirements[1]->colour); ?></li>
            <?php if($enquiryRequirements[1]->additional_features != 'N/A'): ?>
              <li>Additional Features: <?php echo e($enquiryRequirements[1]->additional_features); ?></li>
            <?php endif; ?>
          </ul>
        </div>
        <div class="column">
          <h4 class="box-title">Product Customizations</h4>
          <ul>
            <li>Print Methods: <?php echo e($enquiryRequirements[1]->product_style); ?></li>
            <li>Print Placements: <?php echo e($enquiryRequirements[1]->material); ?></li>
            <li>Print Area: <?php echo e($enquiryRequirements[1]->quality); ?></li>
            <li>Measurements: <?php echo e($enquiryRequirements[1]->fabric); ?></li>
            <?php if($enquiryRequirements[1]->additional_customizations != 'N/A'): ?>
              <li>Additional Customization: <?php echo e($enquiryRequirements[1]->additional_customizations); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <h4>Conditions</h4>
      <ul>
        <li>Finishing: <?php echo e($enquiryRequirements[1]->finishing); ?></li>
        <li>Packaging: <?php echo e($enquiryRequirements[1]->packaging); ?></li>
        <li>Inclusive: <?php echo e($enquiryRequirements[1]->inclusive); ?></li>
        <li>Exclusive: <?php echo e($enquiryRequirements[1]->exclusive); ?></li>
      </ul>


      <div style="page-break-before: always; width: 100%;" class="page-header headerContent">
        <img src="<?php echo e(asset('images/merakiStoreFooterLogo.png')); ?>"
        class="img-fluid figure-img" alt="Meraki Store" style="width: 150px;" />
        <span style="float:right;"><p><strong>MERAKII ENTERPRISES</strong></p>
          <address>
            <p style="font-size: 15px;">
            D.No:101, Near SR Club, Sri Nagar Colony<br>
            Hyderabad, Telangana<br>
            Tel: 040-48554470, 9000909109<br><br>
            Email: <b><i>abhilash.merakii@gmail.com</i></b><br>
          </p>
      </div>
      <br>

      <h4>Terms & Conditions</h4>
      <ul>
        <li>Price mentioned for the above Hoodie is inclusive of material and fabrication, GST 5%, art work
            embroidery charges and shipment charges (Single location).
        </li>
        <li>Excludes all the other details apart from Inclusives mentioned.</li>
        <li>Order will be processed based on the sample approved from the authorised person from the
            client side. Specifications mentioned in this particular document is only for the price mentioned above.</li>
        <li>Final production will take place only on the bases of sample approved irrespective of the
            specifications mentioned in this particular quotation.
        </li>
        <?php if($enquiryQuoteLinkage[0]->specific_terms_1 != 'N/A'): ?>
          <li><?php echo e($enquiryQuoteLinkage[0]->specific_terms_1); ?></li>
        <?php endif; ?>
        <?php if($enquiryQuoteLinkage[0]->specific_terms_2 != 'N/A'): ?>
          <li><?php echo e($enquiryQuoteLinkage[0]->specific_terms_2); ?></li>
        <?php endif; ?>
        <?php if($enquiryQuoteLinkage[0]->specific_terms_3 != 'N/A'): ?>
          <li><?php echo e($enquiryQuoteLinkage[0]->specific_terms_3); ?></li>
        <?php endif; ?>
        <?php if($enquiryQuoteLinkage[0]->specific_terms_4 != 'N/A'): ?>
          <li><?php echo e($enquiryQuoteLinkage[0]->specific_terms_4); ?></li>
        <?php endif; ?>
        <?php if($enquiryQuoteLinkage[0]->specific_terms_5 != 'N/A'): ?>
          <li><?php echo e($enquiryQuoteLinkage[0]->specific_terms_5); ?></li>
        <?php endif; ?>
        <li>The above quotation is for the total quantites as per the requirement, if the quantity reduces
            pricing will be increased proportionatlly.
        </li>
        <li>Every product will have Merakii label to indicate our band.</li>
        <li><b>Payment Terms:</b> Require <?php echo e($enquiryQuoteLinkage[0]->advance_payment_percentage); ?>% as advance on the total value to start the production and the
            balance amount should be paid on or before final delivery.
        </li>
        <li><b>Delivery Schedule:</b> Require production time of <?php echo e($enquiryQuoteLinkage[0]->min_production_days); ?> working days.</li>
      </ul>
      <br>
      <?php if($enquiryQuoteLinkage[0]->additional_notes != 'N/A'): ?>
        <h4>Additional Notes</h4>
        <ul>
          <li><?php echo e($enquiryQuoteLinkage[0]->additional_notes); ?></li>
        </ul>
      <?php endif; ?>

      <div class="row">
        <div class="col-xs-12">
          <p>
            For any legal issues, it is subjected to Hyderabad Judiciary only.<br>
            This Quotation is prepared to our best.
          </p>
          <br><br>
          With Regards<br>
          <b>Meraki Enterprises</b>
          <br><br><br><br>
          (Abhilash Gali)<br>
          Manager-Sales Department<br>
          +91 9000 909 109<br>
        </div>
      </div>



      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
        </div>
      </div>

    </section>
    </section>


  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('printCss'); ?>

  <style type="text/css">

      td {
        padding-left: 10px;
      }

      @page
      {
          size: auto;   /* auto is the initial value */
          margin: 0mm;  /* this affects the margin in the printer settings */
      }

      @media  print {
        body {-webkit-print-color-adjust: exact !important;}

        .headerContent {
          display: block;
        }

        .footerContent {
          display: block;
        }
      }

      @media  screen {

        .headerContent {
          display: none;
        }
        .footerContent {
          display: none;
        }
      }

  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templateNoFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>