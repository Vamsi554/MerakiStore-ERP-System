<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Product Catalog | Meraki Store
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

            <div class="box-header">
              <h3 class="box-title" style="padding-left: 20px;"> <?php echo e($productCatalog->product_category_code); ?> </h3>
            </div>

            <div class="box-body">
             <div class="row">
               <div class="col-md-12">
                 <table class="table table-bordered table-striped">
                   <h4 class="box-title" style="padding-left: 20px;"> Product Details </h4>

                       <tr>
                           <td style="width:30%">Product Category</td>
                           <td>
                             <?php echo e($productCatalog->product_category); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Product Category Code</td>
                           <td>
                             <?php echo e($productCatalog->product_category_code); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Product Description</td>
                           <td>
                             <?php echo e($productCatalog->product_description); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Art Work</td>
                           <td>
                             <?php echo e($productCatalog->art_work); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">HSN Code</td>
                           <td>
                             <?php echo e($productCatalog->hsn_code); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">GST Tax</td>
                           <td>
                             <?php echo e($productCatalog->gst_tax); ?>

                           </td>
                       </tr>

                       <tr>
                           <td style="width:30%">Created By</td>
                           <td>
                             <?php echo e($productCatalog->created_by); ?>

                           </td>
                       </tr>
                  </table>
                  <br>
                  <table class="table table-bordered table-striped">
                    <h4 class="box-title" style="padding-left: 20px;"> Features / Customizations / Conditions </h4>
                    <thead>
                      <tr>
                        <th>Category</th>
                        <th>Enabled Features</th>
                        <th>Disabled Features</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php for($f=0; $f<count($productCategoryArr); $f++): ?>
                      <tr>
                        <td><?php echo e($productCategoryArr[$f]); ?></td>
                        <?php
                          $e = 0;
                          $d = 0;
                          $enableArr = array();
                          $disableArr = array();
                          $custArray = explode("#",$productCatalogCustomizationsArr[$f]);
                          for($v=0; $v<count($custArray); $v++) {
                              $indvFeature = explode("@", $custArray[$v]);
                              if($indvFeature[0] == 'Enable') {
                                  $enableArr[$e] = $indvFeature[1];
                                  $e++;
                              }
                              else {
                                  $disableArr[$d] = $indvFeature[1];
                                  $d++;
                              }
                          }
                        ?>
                        <td>
                          <ul>
                            <?php for($m=0; $m<count($enableArr); $m++): ?>
                              <li><?php echo e($enableArr[$m]); ?></li>
                            <?php endfor; ?>
                          </ul>
                        </td>
                        <td>
                          <ul>
                            <?php for($m=0; $m<count($disableArr); $m++): ?>
                              <li><?php echo e($disableArr[$m]); ?></li>
                            <?php endfor; ?>
                          </ul>
                        </td>
                      </tr>
                    <?php endfor; ?>
                    </tbody>
                  </table>
                  <br>
                  <table class="table table-bordered table-striped">
                    <h4 class="box-title" style="padding-left: 20px;"> Additional Information </h4>
                    <tr>
                        <td style="width:30%">Additional Comments</td>
                        <td>
                          <?php echo e($productCatalog->additional_information); ?>

                        </td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>