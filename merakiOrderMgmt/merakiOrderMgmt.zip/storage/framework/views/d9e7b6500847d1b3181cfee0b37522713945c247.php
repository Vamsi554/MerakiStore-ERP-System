<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php echo e($title); ?>

      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Enquiry | Meraki Store</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(Session::has('success')): ?>
                  <div id="alertMsg" class="alert alert-success" style="display: inline-block;">
                     <?php echo e(Session::get('success')); ?>

                        <?php
                         Session::forget('success');
                        ?>
                   </div>
               <?php endif; ?>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>SNo</th>
                  <th>Lead Person</th>
                  <th>Document No</th>
                  <th>Organization</th>
                  <th>Contact Details</th>
                  <th>Enquiry Status</th>
                  <th>Action</th>
                  <th>View</th>
                  <?php if(\Auth::user()->admin == 'Yes'): ?>
                    <th>Quotations</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php
                  $sNo = 1
                ?>
                <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($sNo++); ?></td>
                    <td style="width: 15%;"><?php echo e($enquiry->concernedLeadPerson); ?></td>
                    <td style="width: 15%;"><?php echo e($enquiry->documentNumber); ?></td>
                    <td style="width: 20%;"><?php echo e($enquiry->organizationName); ?> , <?php echo e($enquiry->eventPlace); ?></td>
                    <td style="width: 20%;"><?php echo e($enquiry->name); ?>, <?php echo e($enquiry->phone); ?></td>
                    <td style="width: 18%;"><?php echo e($enquiry->enquiryStatus); ?></td>
                    <td>
                      <?php if($enquiry->enquiryStatus == 'APPROVED'): ?>
                          <a href="javascript:void(0);" class="btn btn-default disabled">Update</a>
                      <?php else: ?>
                          <a href="<?php echo e(URL::to('/')); ?>/enquiry/updateEnquiry/<?php echo e($enquiry->id); ?>" class="btn btn-warning ml-2">Update</a>
                      <?php endif; ?>

                    </td>
                    <td>
                      <a href="<?php echo e(URL::to('/')); ?>/enquiry/displayEnquiry/<?php echo e($enquiry->id); ?>" class="btn btn-info ml-2">View</a>
                    </td>
                    <?php if(\Auth::user()->admin == 'Yes'): ?>
                      <td>
                      <?php if($enquiry->enquiryStatus == 'REQUEST FOR QUOTATION' || $enquiry->enquiryStatus == 'REQUEST FOR REVISED QUOTATION'): ?>
                          <a href="<?php echo e(URL::to('/')); ?>/enquiry/generateQuote/<?php echo e($enquiry->id); ?>" class="btn btn-primary ml-2">Generate</a>
                      <?php else: ?>
                          <a href="javascript:void(0);" class="btn btn-default disabled">Generate</a>
                      <?php endif; ?>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <a href="<?php echo e(URL::to('/')); ?>/enquiry/createEnquiry" class="btn btn-primary ml-2">Create Enquiry</a>

    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

<script type="text/javascript">

  $(document).ready(function() {

      $("#alertMsg").delay(5000).fadeOut();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>