document.write("<script src='https://code.jquery.com/jquery-3.1.1.min.js'></script>");
document.write("<script src='../../js/bootstrap-datepicker.js'></script>");
